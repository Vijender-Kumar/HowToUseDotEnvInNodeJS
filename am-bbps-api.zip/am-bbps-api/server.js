'use strict';
// loads enviroment variables
require('dotenv').config();
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
var passport = require('passport');

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
app.use(bodyParser.json({type: 'application/json'}));

// Initialize Passport
app.use(passport.initialize());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  next();
});

require('./routes/index')(app, passport);
var listener = app.listen(process.env.PORT, function() {
	console.log(`BBPS API running on port ${process.env.PORT}`);
  console.log("Endpoint -----  /api/bill-fetch/:loan_id")
});

