const MongoClient = require("mongodb").MongoClient;

const MONGODB_URI = process.env.MONGODB_URI;
let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }
  const client = await MongoClient.connect(MONGODB_URI);

  const db = await client.db("artm-lmos");
  cachedDb = db;
  return db;
}
 const loanDetail = async(loan_id) => {
  const db = await connectToDatabase();

const loanStateDetails = await db.collection("loan_states").findOne({ loan_id: loan_id })
return loanStateDetails;
}
const chargeDetail = async(loan_id) => {
  const db = await connectToDatabase();

  const chargeDetails = await db.collection("charges").findOne({ loan_id: loan_id })
  return chargeDetails;
  }
const borrowerInfoDetail = async(loan_id) => {
  const db = await connectToDatabase();

  const borrowerInfoDetails = await db.collection("borrowerinfo_commons").findOne({ loan_id: loan_id })
  return borrowerInfoDetails;
  }
const loanTransactionDetail = async(loan_id) => {
  const db = await connectToDatabase();
  let txnAmount = 0;
  const loanTransactionDetails = await db.collection("loan_transaction_ledgers").find({ loan_id: loan_id , label: "repayment", is_received: "Y", processed:null});
  for await (let ele of loanTransactionDetails){
   txnAmount = txnAmount + ele?.txn_amount
  }
  return txnAmount;
  }
module.exports = {loanDetail,chargeDetail, borrowerInfoDetail, loanTransactionDetail};