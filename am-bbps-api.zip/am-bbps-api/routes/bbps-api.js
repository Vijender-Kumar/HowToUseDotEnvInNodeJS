bodyParser = require("body-parser");
const dbDetails = require("../db/db-query.js");
const axios = require('axios');
bodyParser = require("body-parser");
var passport = require('passport');
const express = require('express');
const app = express();
const MongoClient = require("mongodb").MongoClient;


module.exports = (app, connection) => {
  app.use(bodyParser.json());
  app.get('/api/bill-fetch/:loan_id',
    async (req, res, next) => {
      const MONGODB_URI = process.env.MONGODB_URI;
      let cachedDb = null;

      async function connectToDatabase() {
        if (cachedDb) {
          return cachedDb;
        }
        const client = await MongoClient.connect(MONGODB_URI);

        const db = await client.db("artm-lmos");
        cachedDb = db;
        return db;
      }


      try {
        const db = await connectToDatabase();
        const loan_id = req.params.loan_id;
        const todayDate = new Date();
        let totalDueAmount = "";
        const loanStateDetails = await dbDetails.loanDetail(loan_id);
        console.log("bbps", loanStateDetails)
        const chargeDetails = await dbDetails.chargeDetail(loan_id)
        const loanDetails = await dbDetails.borrowerInfoDetail(loan_id)
        const loanTransactionAmount = await dbDetails.loanTransactionDetail(loan_id)
        let fifthDay = new Date();
        fifthDay = new Date(fifthDay.setDate(todayDate.getDate() + 5));
        let nextRepaymentInstallments = await db.collection("repayment_installments")
          .findOne({ loan_id: loan_id, due_date: { $lte: fifthDay, $gte: todayDate } });

        let nextDueDate = nextRepaymentInstallments?.due_date;
        const installmentAmount = parseFloat(nextRepaymentInstallments?.emi_amount);
        // Loan State overdue amount      
        const interestDue = loanStateDetails?.current_int_due;
        const principalDue = loanStateDetails?.current_prin_due;
        const lpiDue = loanStateDetails?.current_lpi_due;

        //Excess payment amount
        let excessPayment = loanStateDetails?.excess_payment_ledger + loanTransactionAmount;
        if (!excessPayment || isNaN(excessPayment) || excessPayment === null) {
          excessPayment = 0;
        }
        //Total charge excluding foreclosure
        let chargeAmount = chargeDetails?.charge_amount + chargeDetails?.gst - chargeDetails?.total_amount_paid - chargeDetails?.total_amount_waived - chargeDetails?.total_gst_reversed - chargeDetails?.total_gst_paid
        if (!chargeAmount || isNaN(chargeAmount) || chargeAmount === null) {
          chargeAmount = 0;
        }
        let emiAmount = 0;
        if (!loanDetails) {
          throw {
            message: "Invalid details please check and re-enter"
          }
        }

        //Date part
        let dueDate = "";

        if (loanStateDetails?.status?.toLowerCase() === "due") {
          dueDate = (await db.collection("loan_state_audit")
            .find({ loan_id: loan_id, status: "Due" })
            .sort({ due_date: +1 })
            .limit(1)
            .toArray())[0]?.due_date;
          console.log("ps22", dueDate)
          if (!dueDate) throw {
            type: 21,
            message: "Cannot fetch bill as due date does not exist"
          }
        }
        else {
          nextInstallmentDate = nextDueDate;
          console.log("ps22", nextDueDate)

          const nextInstallmentDiffInMilliseconds = Math.abs(nextInstallmentDate - todayDate);
          const diffInDays = parseInt(nextInstallmentDiffInMilliseconds / (1000 * 60 * 60 * 24));
          if (diffInDays <= 5 || diffInDays === 0) {
            dueDate = nextInstallmentDate
            console.log("ps22", dueDate)

          }
          else {
            dueDate = (await db.collection("repayment_installments")
              .find({ loan_id: loan_id, due_date: { $lte: todayDate } })
              .sort({ due_date: -1 })
              .limit(1)
              .toArray())[0]?.due_date;
            console.log("ps23", dueDate)

          }
        }
        totalDueAmount = parseFloat(interestDue) + parseFloat(principalDue) + parseFloat(lpiDue) + parseFloat(installmentAmount) + parseFloat(chargeAmount) - parseFloat(excessPayment);
        console.log(interestDue, principalDue, installmentAmount, chargeAmount, excessPayment, "hhh", totalDueAmount)

        if (totalDueAmount < 0) {
          totalDueAmount = 0;
        }

        res.status(200).send({
          customer_name: loanDetails?.first_name + loanDetails?.last_name,
          timestamp: todayDate,
          biller_transaction_ref_number: `${loan_id}-${Date.now()}`,
          due_date: dueDate,
          totalBill: totalDueAmount
        });

      }
      catch (error) {
        console.log(error);
        if (error.type === 21) {
          res.status(400).send({
            status: "fail",
            message: error.message
          });
        } else {
          res.status(400).send({
            status: "fail",
            message: "System Error",
          })
        }
      }
    });

  // Bill payment API
  app.post("/api/bbps-bill-payment",
    async (req, res) => {
      const apiName = "BBPS-BILL-PAYMENT";
      const requestId = `${req.company.code}-${apiName}-${Date.now()}`;
      try {
        // Request Body
        const bbpsData = {
          amount: req.body.amount,
          ts: req.body.utr_timestamp,
          txnReferenceId: req.body.txn_reference_id,
          billertxnReferenceId: req.body.billertxnReferenceId,
          paymentMode: req.body.payment_mode,
          loan_app_id: req.body.loan_app_id,
          consent: req.body.consent,
          consent_timestamp: req.body.consent_timestamp
        };
        if (req.body.consent === "N") {
          throw {
            errorType: 21,
            message: "Consent was not provided"
          }
        };
        //BBPS URL
        const url = process.env.BBPS_BILL_PAYMENT_URL;

        //Headers
        const config = {
          headers: {
            'Content-Type': 'application/json'
          }
        };
        delete bbpsData.consent;
        delete bbpsData.consent_timestamp;
        delete bbpsData.loan_app_id;
        console.log("This is sending to BBPS:", bbpsData);
        const response = await axios.post(url, bbpsData, config);
        if (response.data.responseCode === "000") {
          res.status(200).send({
            request_id: requestId,
            data: response.data,
            success: true,
          });
        }
      } catch (error) {
        const msgString = error.message.validationmsg || error.errorType ? error.message : `Please contact the administrator`;
        const errorCode = error.message.validationmsg || error.errorType ? 400 : 500;
        if (errorCode == 400 && error.errorType === 21) {
          res.status(400).send({
            requestId: requestId,
            status: "fail",
            message: msgString,
          });
        } else {
          res.status(500).send({
            requestId: requestId,
            status: "fail",
            message: "Please contact the administrator",
          });
        }
      }
    });
}
