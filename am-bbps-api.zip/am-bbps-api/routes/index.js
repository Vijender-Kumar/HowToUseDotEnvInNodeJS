"use strict";
function includeAllRoutes(app, passport) {
  require("./bbps-api.js")(app, passport);
}

module.exports = function(app, passport) {
  includeAllRoutes(app, passport);
};
