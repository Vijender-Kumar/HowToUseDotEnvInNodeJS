const LoanCustomIdSchema = require("../models/loan-custom-id-schema.js");
const Customers = require('../models/customer-schema');

const generateRandomString = (length, chars) => {
  var result = '';
  for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
  return result;
}

const generateSequence = (num, size) => {
  var sequence = num + "";
  while (sequence.length < size) sequence = "0" + sequence;
  return sequence;
}

const generatedLoanId = async (customCode, productLoanKey, data) => {
  try {
    const loanCount = await LoanCustomIdSchema.getCount();
    const sequence = generateSequence(loanCount + 1, 11)
    const recordLoanCustomId = await LoanCustomIdSchema.updateUpsertById(sequence, {
      loan_custom_id: sequence,
      loan_app_id: data.loan_app_id
    })
    const loanCustomIdExist = await LoanCustomIdSchema.findByCondition({
      loan_custom_id: sequence,
      loan_app_id: data.loan_app_id
    })
    if(!loanCustomIdExist){
       throw{
             errorData:"Something went wrong, please retry."
            }
    }
    const loanId = `AML${customCode}${productLoanKey}1${loanCustomIdExist.loan_custom_id}`
    return loanId;
  } catch (error) {
    return error;
  }
}

const handleCreateCustomerId = async () => {
  const customerCount = await Customers.getCount();
  const sequence = generateSequence(customerCount + 1, 10);
  return String(sequence);
}

const generateCustomerId = async (leads) => {
  var newLeadsArr = [];
  const promise = new Promise((resolve, reject) => {
    try {
      let counter = 0;
      leads.map(async (record) => {
        const findCustomer = await Customers.findByPan(record?.appl_pan);
        const cust_id = findCustomer.length ? findCustomer[0].cust_id :
          await handleCreateCustomerId();
        if (!findCustomer.length) {
          const customerData = {
            cust_id: String(cust_id),
            pan: record?.appl_pan,
            first_name: record.first_name,
            middle_name: record.middle_name,
            last_name: record.last_name,
          }
          const addCustomer = await Customers.addNew(customerData);
        }
        record.cust_id = cust_id
        newLeadsArr.push(record);
        counter++;
        if (counter == leads.length) resolve(newLeadsArr);
      })
    } catch (error) {
      reject(error);
    }
  });
  return promise;
};

module.exports = {
  generateRandomString,
  generateSequence,
  generatedLoanId,
  generateCustomerId,
};