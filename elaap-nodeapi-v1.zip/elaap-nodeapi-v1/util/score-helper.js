const AScoreSchema = require("../models/a-score-schema.js");
const BScoreSchema = require("../models/b-score-schema.js");
const OfferDetailsSchema = require("../models/offer-details-schema.js");

const processAscore = async (req, data) => {
  try {
    // Fetch data from a_score by req_id
    const aScoreData = await AScoreSchema.findByReqId(data.a_score_request_id);
    if (!aScoreData) throw { success: false, message: "A score not found." };
    return {
      success: true,
      score: aScoreData.score,
      bureau_score: aScoreData?.bureau_score
    };
  } catch (error) {
    return error;
  }
};

const processBscore = async (req, data) => {
  try {
    // Fetch data from b_score by req_id
    const bScoreData = await BScoreSchema.findByReqId(data.b_score_request_id);
    if (!bScoreData) throw { success: false, message: "B score not found." };
    return {
      success: true,
      score: bScoreData.score,
      offered_amount: bScoreData?.offered_amount,
      offered_int_rate: bScoreData?.offered_int_rate,
      monthly_imputed_income: bScoreData?.monthly_imputed_income,
      monthly_average_balance: bScoreData?.monthly_average_balance,
      foir: bScoreData?.foir
    };
  } catch (error) {
    return error;
  }
};

const processOfferDetails = async (req, loan_app_id) => {
  try {
    // Fetch data from b_score by req_id
    const offerDetailsData = await OfferDetailsSchema.getByLoanAppId(
      loan_app_id
    );
    if (!offerDetailsData)
      throw { success: false, message: "B score not found." };
    return {
      success: true,
      offered_amount: offerDetailsData?.offered_amount,
      offered_int_rate: offerDetailsData?.offered_int_rate,
      monthly_imputed_income: offerDetailsData?.monthly_imputed_income,
      monthly_average_balance: offerDetailsData?.monthly_average_balance,
      foir: offerDetailsData?.foir,
      loan_app_id: offerDetailsData?.loan_app_id
    };
  } catch (error) {
    return error;
  }
};

module.exports = {
  processAscore,
  processBscore,
  processOfferDetails
};
