const { pan_adhar_ocr } = require('../../services/pan_adhar_ocr/pan_adhar_ocr.js')
const Compliance = require('../../models/compliance-schema')
const LoanRequest = require('../../models/loan-request-schema.js')
const { convertDateTime } = require('../../util/helper.js')
const loanedits = require("../../util/loanedits")
const moment = require("moment");

const aadhar_pan_image_parser_fxn = async (body) => {


    if (body.loan_app_id == "" || body.loan_app_id == undefined) {


        throw {
            message: {
                loan_app_id: ["Loan app id is missing"]
            },
            success: false
        }


    }

    else if (body.code == "" || body.code == undefined) {

        throw {
            message: {
                code: ["Code is missing"]
            },
            success: false
        }


    }


    else if (body.base64pdfencodedfile == "") {

        throw {
            message: {
                base64pdfencodedfile: ["File should not be empty"]
            },
            success: false
        }


    }

    else if (body.base64pdfencodedfile == undefined) {
        throw {
            message: {
                base64pdfencodedfile: ["File is mandatory"]
            },
            success: false
        }


    }

    const kyc_checklist_data = await LoanRequest.findOneWithLoanId(body.loan_app_id)



    if (!kyc_checklist_data) {
        throw {
            message: "Error while parsing the document",
            success: false
        }
    }


    let data = {
        aadhaar_received: "N",
        aadhaar_verified: "N",
        pan_received: "N",
        pan_verified: "N",
        selfie_received: "N",
        company_id: kyc_checklist_data.company_id,
        product_id: kyc_checklist_data.product_id,
        loan_id: kyc_checklist_data.loan_id,
        loan_app_id: body.loan_app_id
    }

    const findKycChecklistData = await Compliance.findByLoanAppId(body.loan_app_id)


    if (!findKycChecklistData) {
        const addKycCheckList = await Compliance.addNew(data);

        if (!addKycCheckList) {
            throw {
                message: "Error while parsing the document",
                success: false
            }
        }
    }




    const loan_id = body.loan_app_id
    const file = body.base64pdfencodedfile.replace(/^data:(.*,)?/, "");


    const time_stamp = await LoanRequest.findOneWithLoanId(loan_id)

    if (!time_stamp) {
        throw {
            message: "Error while parsing the document",
            success: false
        }


    }
    let consent_timestamp = convertDateTime(time_stamp.created_at)



    let ocr_resp = await pan_adhar_ocr(loan_id, file, consent_timestamp)

    if (ocr_resp.status) {
        if (ocr_resp.status == 'fail') {
            throw {
                message: ocr_resp.message,
                success: false
            }


        }

    }

    if (ocr_resp.length == 0) {
        throw {
            message: "Inavlid document please upload the correct document",
            success: false
        }

    } else {

        ///get the parsed AadhaarFrontBottom values 
        let AadhaarFrontBottom = ocr_resp.find(parsedData => {
            if (parsedData.type == 'Aadhaar Front Bottom') {
                return parsedData
            }
        })

        ///get the parsed AadhaarBack values 
        let AadhaarBack = ocr_resp.find(parsedData => {
            if (parsedData.type == 'Aadhaar Back') {
                return parsedData
            }
        })
        ///get the parsed AadhaarFrontTop values 
        let AadhaarFrontTop = ocr_resp.find(parsedData => {
            if (parsedData.type == 'Aadhaar Front Top') {
                return parsedData
            }
        })

        if (ocr_resp.length >= 2 && typeof AadhaarBack === 'object') {

            let aadhar_fname = ''
            let aadhar_lname = ''
            let aadhaar_mname = ''
            let aadhaar_dob = ''
            let aadhaar_pincode = ''
            let parsed_aadhaar_number = ''
            //if documents with multiple image for aadhaar front
            if ((loanedits.documentMapping[body.code] == "aadhar_card" && typeof AadhaarFrontBottom == 'object')) {
                const wholeAadharReceived = await Compliance.updateAadhaarReceivedByLoanId(loan_id, "Y")
                if (!wholeAadharReceived) {
                    throw {
                        message: "Cannot update the Aadhar",
                        success: false
                    }
                }


                let space = AadhaarFrontBottom.details.name.value.indexOf(" ");
                let blur1 = AadhaarBack.details.qualityCheck.isBlur == "no" ? true : false
                let blur2 = AadhaarFrontBottom.details.qualityCheck.isBlur == "no" ? true : false

                aadhaar_pincode = AadhaarBack.details.pin.value,
                    aadhar_fname = space >= 0 ? AadhaarFrontBottom.details.name.value.substring(0, space) : AadhaarFrontBottom.details.name.value,
                    aadhar_lname = AadhaarFrontBottom.details.name.value.split(' ').length >= 2 ? AadhaarFrontBottom.details.name.value.split(' ')[AadhaarFrontBottom.details.name.value.split(' ').length - 1] : "",
                    aadhaar_dob = moment(AadhaarFrontBottom.details.dob.value, "DD/MM/YYYY").format("YYYY-MM-DD"),
                    parsed_aadhaar_number = `xxxxxxxx${AadhaarFrontBottom.details.aadhaar.value.substr(-4)}`,
                    aadhaar_mname = AadhaarFrontBottom.details.name.value.split(' ').length == 3 ? AadhaarFrontBottom.details.name.value.split(' ')[1] : ""


                //check for required fields
                if (aadhaar_dob != "" && aadhar_fname != "" && parsed_aadhaar_number != "" && aadhaar_pincode != "") {
                    const updateAadharNumberInCompliance = await Compliance.updateAadharParsedOcrNumber(loan_id, parsed_aadhaar_number)
                    const updateLoanRequestOcr = await LoanRequest.updateAadharDetailsByLoanId(loan_id, aadhar_fname, aadhar_lname, aadhaar_dob, aadhaar_pincode, parsed_aadhaar_number, aadhaar_mname)
                    if (!updateLoanRequestOcr) {
                        throw {
                            message: "Cannot update the document",
                            success: false
                        }

                    } else {
                        const wholeAadharVerified = await Compliance.updateAadhaarVerifiedByLoanId(loan_id, "Y")
                        if (!wholeAadharVerified) {
                            throw {
                                message: "Cannot update the document",
                                success: false
                            }

                        } else {
                            return {
                                code: 200, msg: "Aadhar Updated And Verified"
                            }

                        }
                    }
                } else {
                    throw {
                        message: "Invalid document, please try again",
                        success: false
                    }


                }

            }
            //if documents with multiple image for aadhaar back
            else if (loanedits.documentMapping[body.code] == "aadhaar_card_back" && typeof AadhaarBack == 'object') {
                // const findFrontValues = await LoanRequest.findValuesForBackAadhaar(loan_id)

                const blur = AadhaarBack.details.qualityCheck.isBlur == "no" ? true : false
                let aadhaar_pincode = AadhaarBack.details.pin.value

                if (aadhaar_pincode != "") {
                    const updateLoanRequestOcr = await LoanRequest.updateBackAadharDetailsByLoanId(loan_id, aadhaar_pincode)
                    if (!updateLoanRequestOcr) {
                        throw {
                            message: "Error while parsing the document",
                            success: false
                        }
                    }
                    else {
                        //check if aadhaar front values are present is already present
                        const findFrontValues = await LoanRequest.findValuesForBackAadhaar(loan_id)
                        if (findFrontValues.aadhar_fname != "" && findFrontValues.aadhar_dob != "" && findFrontValues.parsed_aadhaar_number != "") {
                            //update as verified if present
                            const AadhaarVerified = await Compliance.updateAadhaarVerifiedByLoanId(loan_id, "Y")
                        }

                        return {
                            code: 200,
                            msg: "Aadhar Updated And Verified",
                        }

                    }
                } else {
                    throw {
                        message: "Invalid document, please try again",
                        success: false
                    }
                }
            }
            else {
                throw {
                    message: "Incorrect code, please provide the correct code for aadhar document",
                    success: false
                }
            }

        } else if (ocr_resp[0].type == "Pan") {
            if ((loanedits.documentMapping[body.code] == "pan_card" && ocr_resp[0].type.toLowerCase().includes("pan"))) {
                const panReceieved = await Compliance.updatePanReceivedByLoanId(loan_id, "Y")
                if (!panReceieved) {
                    throw {
                        message: "Error while parsing the document",
                        success: false
                    }
                }
                let space = ocr_resp[0].details.name.value.indexOf(" ");
                let space1 = ocr_resp[0].details.father.value.indexOf(" ");
                const blur = ocr_resp[0].details.qualityCheck.isBlur == "no" ? true : false
                let pan_fname = space >= 0 ? ocr_resp[0].details.name.value.substring(0, space) : ocr_resp[0].details.name.value
                let pan_lname = ocr_resp[0].details.name.value.split(' ').length >= 2 ? ocr_resp[0].details.name.value.split(' ')[ocr_resp[0].details.name.value.split(' ').length - 1] : ""
                let pan_dob = moment(ocr_resp[0].details.date.value, "DD/MM/YYYY").format("YYYY-MM-DD")
                let pan_father_fname = space >= 0 ? ocr_resp[0].details.father.value.substring(0, space1) : ocr_resp[0].details.father.value
                let pan_father_lname = space >= 0 ? ocr_resp[0].details.father.value.substring(space1 + 1) : ""
                let parsed_pan_number = ocr_resp[0].details.panNo.value
                let pan_middle_name = ocr_resp[0].details.name.value.split(' ').length == 3 ? ocr_resp[0].details.name.value.split(' ')[1] : ""
                if (pan_dob != "" && pan_fname != "" && parsed_pan_number != "") {
                    const updatePanInCompliance = await Compliance.updatePanParsedOcrNumber(loan_id, parsed_pan_number)
                    const updatePanLoanRequest = await LoanRequest.updatePanDetailsByLoanId(loan_id, pan_fname, pan_lname, pan_dob, parsed_pan_number, pan_father_fname, pan_father_lname, pan_middle_name)
                    if (!updatePanLoanRequest) {
                        throw {
                            message: "Error while parsing the document",
                            success: false
                        }
                    } else {
                        const panVerified = await Compliance.updatePanVerifiedByLoanId(loan_id, "Y")
                        if (!panVerified) {
                            throw {
                                message: "Error while parsing the document",
                                success: false
                            }

                        } else {
                            return {
                                code: 200,
                                msg: "Pan Updated And Verified"
                            }
                        }
                    }
                } else {
                    throw {
                        message: "Invalid document, please try again",
                        success: false
                    }

                }

            } else {
                throw {
                    message: "Incorrect code, please provide the correct code for pan document",
                    success: false
                }
            }

        } else if (ocr_resp[0].type == "Aadhaar Back" && ocr_resp[0].details.hasOwnProperty('pin') && ocr_resp[0].details.hasOwnProperty('address')) {

            if ((loanedits.documentMapping[body.code] == "aadhaar_card_back")) {
                const findFrontValues = await LoanRequest.findValuesForBackAadhaar(loan_id)
                //check for aadhaar front details
                if (findFrontValues.aadhar_fname != "" && findFrontValues.aadhar_dob != "" && findFrontValues.parsed_aadhaar_number != "") {
                    const blur = AadhaarBack.details.qualityCheck.isBlur == "no" ? true : false
                    let aadhaar_pincode = AadhaarBack.details.pin.value 
                    if (aadhaar_pincode != "") {
                        const updateLoanRequestOcr = await LoanRequest.updateBackAadharDetailsByLoanId(loan_id, aadhaar_pincode)
                        if (!updateLoanRequestOcr) {
                            throw {
                                message: "Error while parsing the document",
                                success: false
                            }

                        }
                        else {
                            const AadhaarVerified = await Compliance.updateAadhaarVerifiedByLoanId(loan_id, "Y")
                            if (!AadhaarVerified) {
                                throw {
                                    message: "Error while parsing the document",
                                    success: false
                                }

                            } else {
                                return {
                                    code: 200,
                                    msg: "Aadhar Updated And Verified",
                                }

                            }
                        }

                    } else {
                        throw {
                            message: "Invalid document, please try again",
                            success: false
                        }
                    }
                } else {
                    ///update the aadhaar pincode
                    const blur = ocr_resp[0].details.qualityCheck.isBlur == "no" ? true : false
                    let aadhaar_pincode = ocr_resp[0].details.pin.value
                    if (aadhaar_pincode != "") {
                        const updateLoanRequestOcr = await LoanRequest.updateBackAadharDetailsByLoanId(loan_id, aadhaar_pincode)
                        if (!updateLoanRequestOcr) {
                            throw {
                                message: "Error while parsing the document",
                                success: false
                            }
                        } else {
                            return {
                                code: 200,
                                msg: "Aadhar Updated And Verified",
                            }
                        }
                    } else {
                        throw {
                            message: "Invalid document, please try again",
                            success: false
                        }
                    }

                }

            } else {
                throw {
                    message: "Incorrect code, please provide the correct code for aadhar back document",
                    success: false
                }

            }


        } else if (AadhaarFrontBottom) {
            if ((loanedits.documentMapping[body.code] == "aadhar_card")) {
                const AadhaarRecieved = await Compliance.updateAadhaarReceivedByLoanId(loan_id, "Y")
                if (!AadhaarRecieved) {
                    throw {
                        message: "Error while parsing the document",
                        success: false
                    }
                }

                const blur = AadhaarFrontBottom.details.qualityCheck.isBlur == "no" ? true : false
                let space = AadhaarFrontBottom.details.name.value.indexOf(" ");
                let aadhar_fname = space >= 0 ? AadhaarFrontBottom.details.name.value.substring(0, space) : AadhaarFrontBottom.details.name.value
                let aadhar_lname = AadhaarFrontBottom.details.name.value.split(' ').length >= 2 ? AadhaarFrontBottom.details.name.value.split(' ')[AadhaarFrontBottom.details.name.value.split(' ').length - 1] : ""
                let aadhaar_dob = moment(AadhaarFrontBottom.details.dob.value, "DD/MM/YYYY").format("YYYY-MM-DD")
                let parsed_aadhaar_number = `xxxxxxxx${AadhaarFrontBottom.details.aadhaar.value.substr(-4)}`
                let aadhaar_middle_name = AadhaarFrontBottom.details.name.value.split(' ').length == 3 ? AadhaarFrontBottom.details.name.value.split(' ')[1] : ""
                if (aadhar_fname != "" && aadhaar_dob != "" && parsed_aadhaar_number != "") {
                    const updateAadharNumberInCompliance = await Compliance.updateAadharParsedOcrNumber(loan_id, parsed_aadhaar_number)
                    const updateLoanRequestOcr = await LoanRequest.updateAadharFrontDetailsByLoanId(loan_id, aadhar_fname, aadhar_lname, aadhaar_dob, parsed_aadhaar_number, aadhaar_middle_name)

                    //check if pincode is already present
                    const findFrontValues = await LoanRequest.findValuesForBackAadhaar(loan_id)
                    if (findFrontValues.aadhaar_pincode) {
                        //update as verified if present
                        const AadhaarVerified = await Compliance.updateAadhaarVerifiedByLoanId(loan_id, "Y")
                    }

                    if (!updateLoanRequestOcr) {
                        throw {
                            message: "Error while parsing the document",
                            success: false
                        }

                    } else {

                        return ({
                            code: 200,
                            msg: 'Aadhar back document is pending to be uploaded.',
                        });

                    }

                } else {
                    throw {
                        message: "Invalid document, please try again",
                        success: false
                    }

                }



            }
            else {
                throw {
                    message: "Incorrect code, Please provide the correct code for aadhar document",
                    success: false
                }


            }

        }
    }



};

module.exports = {
    aadhar_pan_image_parser_fxn
};