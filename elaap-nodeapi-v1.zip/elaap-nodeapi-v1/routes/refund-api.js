const jwt = require("../util/jwt");
const axios = require("axios");
const BorrowerinfoCommon = require("../models/borrowerinfo-common-schema");
const DisbursementChannelConfig = require("../models/disbursement-channel-config-schema");
const DisbursementChannelMasterScehema = require("../models/disbursement-channel-master-schema.js");
const DisbursementLedgerSchema = require("../models/disbursement-ledger-schema");
const UniqueReferenceDisburesementSchema = require("../models/unique-reference-disbursement-schema.js");
const borrowerHelper = require("../util/borrower-helper.js");
const moment = require("moment");

const checkDisbursementChannelBalance = async (
  company_id,
  product_id,
  disbursement_channel
) => {
  let totalDebitAmount = 0;
  let totalCreditAmount = 0;
  const channelTransactions = await DisbursementLedgerSchema.findByCondition({
    company_id,
    product_id,
    disbursement_channel
  });
  channelTransactions.forEach((row, index) => {
    if (row.txn_entry.toLowerCase() == "dr" && row.txn_stage === "1") {
      totalDebitAmount += parseFloat(row.amount ? row.amount : 0);
    }
    if (row.txn_entry.toLowerCase() == "cr") {
      totalCreditAmount += parseFloat(row.amount ? row.amount : 0);
    }
  });
  const availableBalance = totalCreditAmount - totalDebitAmount;
  return availableBalance;
};

module.exports = (app, connection) => {
  app.use(bodyParser.json());

  app.get(
    "/api/refund-details/:loan_id",
    [jwt.verifyToken, jwt.verifyUser, jwt.verifyCompany, jwt.verifyProduct],
    borrowerHelper.isLoanExistByLID,
    async (req, res, next) => {
      try {
        const loan_id = req.params.loan_id;
        // Validate if loan is in disbursed status
        if (req.loanData.stage !== 4)
          throw {
            success: false,
            message: `Unable to get refund details as loan is in ${req.loanData.status} status`
          };

        let disbursementDate = moment(
          req.loanData.disbursement_date_time,
          "YYYY-MM-DD"
        );
        let finalApproveDate = moment(
          req.loanData.final_approve_date,
          "YYYY-MM-DD"
        );
        let refundDays = disbursementDate.diff(finalApproveDate, "days");

        // Calculate refund amount
        const refund_amount =
          (Number(req.loanData.sanction_amount) *
            Number(req.loanData.loan_int_rate) *
            Number(refundDays)) /
          (100 * 365);

        let responseData = {
          int_refund_amount:
            req.loanData.int_refund_amount ||
            Math.round((refund_amount * 1 + Number.EPSILON) * 100) / 100,
          int_refund_days: req.loanData.int_refund_days || refundDays,
          interest_refund_status:
            req.loanData.int_refund_status || "NotInitiated",
          interest_refund_date_time: req.loanData.int_refund_date_time
            ? req.loanData.int_refund_date_time
            : "",
          refund_triggered_by: req.loanData.refund_triggered_by
            ? req.loanData.refund_triggered_by
            : "",
          int_refund_request_date_time:
            req.loanData.int_refund_request_date_time
        };
        return res.status(200).send({
          success: true,
          data: responseData
        });
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.post(
    "/api/initiate-interest-refund",
    [jwt.verifyToken, jwt.verifyUser, jwt.verifyCompany, jwt.verifyProduct],
    borrowerHelper.isLoanExistByLID,
    borrowerHelper.fetchLeadData,
    async (req, res) => {
      const reqData = req.body;
      try {
        // Return if allow_loc flag is true in product
        if (req.product.allow_loc === 1)
          throw {
            success: false,
            message:
              "As provided product is line of credit can't make call to composite disbursement "
          };

        // Validate if loan is in disbursed status
        if (req.loanData.stage !== 4)
          throw {
            success: false,
            message: `Unable to initiate refund as loan is in ${req.loanData.status} status`
          };

        // Validate refund_amount and int_refund_days.
        let disbursementDate = moment(
          req.loanData.disbursement_date_time,
          "YYYY-MM-DD"
        );
        let finalApproveDate = moment(
          req.loanData.final_approve_date,
          "YYYY-MM-DD"
        );

        //Check whether the disbursement channel is configured
        const disbursementChannel =
          await DisbursementChannelConfig.getDisburseChannel({
            company_id: req.company._id,
            product_id: req.product._id
          });
        if (!disbursementChannel)
          throw {
            success: false,
            message: `Disburse channel is not configured for ${req.company.name} `
          };
        const disbursementChannelMaster =
          await DisbursementChannelMasterScehema.findOneByTitle(
            disbursementChannel.disburse_channel
          );
        if (!disbursementChannelMaster)
          throw {
            success: false,
            message: `Global disbursement channel not found`
          };

        if (!Number(disbursementChannelMaster.status))
          throw {
            success: false,
            message: `Global disbursement channel is not active, kindly contact system administrator.`
          };
        if (!disbursementChannel)
          throw {
            success: false,
            message: `Product don't have this channel configured , kindly contact system administrator.`
          };

        if (!Number(disbursementChannel.status))
          throw {
            success: false,
            message: `Disburse channel config for this product is not active, kindly contact system administrator.`
          };

        if (disbursementChannel.wallet_config_check === "1") {
          const availableChannelBalance = await checkDisbursementChannelBalance(
            req.company._id,
            req.product._id,
            disbursementChannelMaster.title
          );
          if (
            parseFloat(availableChannelBalance) <
            parseFloat(reqData.net_disbur_amt)
          ) {
            throw {
              success: false,
              message:
                "Insufficient balance, kindly top up disbursement channel"
            };
          }
        }
        //************* Make call to the bank disbursement api. *************

        let uniqueReferenceCount =
          await UniqueReferenceDisburesementSchema.countByLoanId(
            req.loanData.loan_id
          );
        uniqueReferenceCount =
          uniqueReferenceCount < 9
            ? `0${Number(uniqueReferenceCount + 1)}`
            : uniqueReferenceCount + 1;
        let loan_id_portion = `${req.loanData.loan_id.substr(
          req.loanData.loan_id.length - 11
        )}R`;
        let refund_req_id = `${loan_id_portion}${uniqueReferenceCount}`;

        await UniqueReferenceDisburesementSchema.addNew({
          loan_id: req.loanData.loan_id,
          req_id: refund_req_id
        });

        const disbData = {
          loan_app_id: req.loanData.loan_app_id,
          loan_id: refund_req_id,
          borrower_id: req.loanData.borrower_id,
          partner_loan_app_id: req.loanData.partner_loan_app_id,
          partner_loan_id: req.loanData.partner_loan_id,
          partner_borrower_id: req.loanData.partner_borrower_id,
          borrower_mobile: req.leadData.appl_phone,
          txn_date: moment(Date.now()).format("YYYY-MM-DD"),
          company_name: req.company.name,
          code: req.company.code,
          company_id: req.company._id,
          product_id: req.product._id,
          txn_id: `${reqData.loan_id}${new Date().getTime()}`,
          disburse_channel: disbursementChannelMaster.title,
          amount: reqData.refund_amount,
          debit_account_no: disbursementChannel.debit_account,
          debit_ifsc: disbursementChannel.debit_account_ifsc,
          debit_trn_remarks: reqData.loan_id,
          beneficiary_ifsc: req.loanData.borro_bank_ifsc,
          beneficiary_account_no: req.loanData.borro_bank_acc_num,
          beneficiary_name: req.loanData.borro_bank_account_holder_name,
          mode_of_pay: "PA",
          //Send refund webhook URL to bank in case of refund
          webhook_link: process.env.REFUND_WIREOUT_URL,
          access_token: process.env.REFUND_WIREOUT_SECRET
        };
        const config = {
          method: "post",
          url: disbursementChannelMaster.endpoint,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Basic ${disbursementChannelMaster.secret_key}`
          },
          data: disbData
        };
        const disbursementResponse = await axios(config);
        if (disbursementResponse.data) {
          //after response from bank disbursement api update the refund data in borrower_info_common table
          updateLoanStatus = await BorrowerinfoCommon.updateLoanStatus(
            {
              refund_request_date_time: moment(Date.now()).format("YYYY-MM-DD"),
              int_refund_days: req.body.int_refund_days,
              refund_amount: req.body.refund_amount,
              refund_triggered_by: req.user.username,
              int_refund_status: "Initiated"
            },
            reqData.loan_id
          );

          //Make debit entry in  disbursement_and_topup schema
          const disbursementDebitData = {
            company_id: req.company._id,
            product_id: req.product._id,
            disbursement_channel: disbursementChannelMaster.title,
            txn_id: disbursementResponse.data.txn_id,
            amount: reqData.refund_amount,
            loan_id: reqData.loan_id,
            refund_req_id: refund_req_id,
            borrower_id: req.loanData.borrower_id,
            partner_loan_id: req.loanData.partner_loan_id,
            partner_borrower_id: req.loanData.partner_borrower_id,
            txn_date: moment(Date.now()).format("YYYY-MM-DD"),
            bank_name: req.loanData.borro_bank_account_holder_name,
            bank_account_no: req.loanData.borro_bank_acc_num,
            bank_ifsc_code: req.loanData.borro_bank_ifsc,
            borrower_mobile: req.leadData.appl_phone,
            txn_entry: "dr",
            txn_stage: "",
            label: "Refund",
            label_type: reqData.label_type
          };
          const recordDebit = await DisbursementLedgerSchema.addNew(
            disbursementDebitData
          );
          return res.status(200).send({
            success: true,
            loan_id: reqData.loan_id,
            response: disbursementResponse.data
          });
        }
      } catch (error) {
        console.log("error===", error);
        if (error.code === "ECONNREFUSED") {
          return res.status(400).send({
            success: false,
            message: "Service unavailable. Please try again later."
          });
        }
        return res.status(400).send(error);
      }
    }
  );
};
