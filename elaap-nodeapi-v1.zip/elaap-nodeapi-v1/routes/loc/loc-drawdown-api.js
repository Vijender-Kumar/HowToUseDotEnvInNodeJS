
const LocDrawDownSchema = require('../../models/loc-batch-drawdown-schema')

module.exports = (app, connection) =>  {
    app.use(bodyParser.json());

    //api to get the drawdown requests against loan id
    app.get("/api/loc-drawdown-request/:loan_id",

    async (req, res) => {
        try{
            const { loan_id } = req.params
            //fetch data from loc drawdown
            const drawdownRequests = await LocDrawDownSchema.getAllByLoanId(loan_id)

            if (drawdownRequests.length == 0) {
                throw {
                    sucess: false,
                    message:
                        "No records found for loan id",
                };
            }

            return res.status(200).send({
                success: true,
                data: drawdownRequests,
            });


        }catch(error){
            return res.status(404).json(error)
        }
    })


}