const bodyParser = require("body-parser");
const {check, validationResult} = require("express-validator");
const jwt = require("../util/jwt");
const LoanState = require("../models/loan-state-schema.js");
const LoanStateAudit = require("../models/loan-state-audit-schema.js");
const BorrowerinfoCommon = require("../models/borrowerinfo-common-schema.js");
const moment = require("moment");

module.exports = (app, connection) => {
  app.use(bodyParser.json());

  const findLoanExist = async (loan_id, req) => {
    try {
      // Check if loan id exist in borrower info common table
      const loanData = await BorrowerinfoCommon.findOneWithKLID(loan_id);
      if (!loanData)
        throw {
          success: false,
          message: "No records found against provided loan id in borrowerinfo."
        };
      // Validate company and product from token with borrower data
      if (loanData.company_id !== req.company._id)
        throw {
          success: false,
          message: "company_id mismatch in authorization."
        };
      if (loanData.product_id !== req.product._id)
        throw {
          success: false,
          message: "product_id mismatch in authorization."
        };
      return loanData;
    } catch (error) {
      return error;
    }
  };

  const prepareResponseData = async (
    loanData,
    loanStatesResp,
    loanStatesAuditResp
  ) => {
    try {
      let reconSummaryData;
      let currentDueData;
      let totalPaidData;
      let installmentAndRepaymentData = [];
      let finalRespData = {};
      // Prepare Recon summary data
      reconSummaryData = {
        loan_id: loanData.loan_id,
        customer_name: `${loanData?.first_name} ${loanData?.last_name}`,
        prin_os: loanStatesResp.prin_os ? loanStatesResp.prin_os : 0,
        int_os: loanStatesResp.int_os ? loanStatesResp.int_os : 0,
        accrual_interest: loanStatesResp.int_accrual
          ? loanStatesResp.int_accrual
          : 0,
        dpd: loanStatesResp.dpd ? loanStatesResp.dpd : 0
      };
      // Prepare Current Due data
      currentDueData = {
        principal_due: loanStatesResp.current_prin_due
          ? loanStatesResp.current_prin_due
          : 0,
        interest_due: loanStatesResp.current_int_due
          ? loanStatesResp.current_int_due
          : 0,
        lpi_due: loanStatesResp.current_lpi_due
          ? loanStatesResp.current_lpi_due
          : 0,
        charges_due: loanStatesResp.current_charges_due
          ? loanStatesResp.current_charges_due
          : 0,
        gst_due: loanStatesResp.current_gst_due
          ? loanStatesResp.current_gst_due
          : 0
      };
      // Prepare total paid data.
      totalPaidData = {
        interest_paid: loanStatesResp.total_int_paid
          ? loanStatesResp.total_int_paid
          : 0,
        principal_paid: loanStatesResp.total_prin_paid
          ? loanStatesResp.total_prin_paid
          : 0,
        lpi_paid: loanStatesResp.total_lpi_paid
          ? loanStatesResp.total_lpi_paid
          : 0,
        chargse_paid: loanStatesResp.total_charges_paid
          ? loanStatesResp.total_charges_paid
          : 0,
        gst_paid: loanStatesResp.total_gst_paid
          ? loanStatesResp.total_gst_paid
          : 0
      };
      // prepare  Instalments & Repayments data.
      loanStatesAuditResp.forEach(record => {
        installmentAndRepaymentData.push({
          installment_number: record.intsalment_num ? record.intsalment_num : 0,
          installment_amount_due: record.amount_due ? record.amount_due : 0,
          principal_due: record.prin_due ? record.prin_due : 0,
          interest_due: record.int_due ? record.int_due : 0,
          lpi_due: record.lpi_due ? record.lpi_due : 0,
          due_date: record.due_date
            ? moment(record.due_date).format("YYYY-MM-DD")
            : "",
          principal_paid: record.prin_paid ? record.prin_paid : 0,
          interest_paid: record.int_paid ? record.int_paid : 0,
          lpi_paid: record.lpi_paid ? record.lpi_paid : 0,
          paid_date: record.paid_date || "",
          status: record.status || "",
          payments: record.payments || []
        });
      });

      finalRespData.reconSummaryData = reconSummaryData;
      finalRespData.currentDueData = currentDueData;
      finalRespData.totalPaidData = totalPaidData;
      finalRespData.installmentAndRepaymentData = installmentAndRepaymentData;
      return finalRespData;
    } catch (error) {
      return error;
    }
  };

  app.get(
    "/api/recon-details/:loan_id",
    [jwt.verifyToken, jwt.verifyUser, jwt.verifyCompany, jwt.verifyProduct],
    async (req, res) => {
      try {
        const {loan_id} = req.params;
        const loanData = await findLoanExist(loan_id, req);
        if (loanData.success === false) throw loanData;
        // Fetch data from loan states table against loan id
        const loanStatesResp = await LoanState.findByLID(loan_id);
        if (!loanStatesResp)
          throw {
            success: false,
            message: "No records found in loan states against provided loan_id."
          };
        // Fetch data aginst loan_id from loan_state_audit table
        const loanStatesAuditResp = await LoanStateAudit.findByLID(loan_id);
        if (!loanStatesAuditResp)
          throw {
            success: false,
            message:
              "No records found in loan state audit against provided loan id."
          };
        const finalRespData = await prepareResponseData(
          loanData,
          loanStatesResp,
          loanStatesAuditResp
        );
        return res.status(200).send(finalRespData);
      } catch (error) {
        console.log(error);
        return res.status(400).send(error);
      }
    }
  );
};
