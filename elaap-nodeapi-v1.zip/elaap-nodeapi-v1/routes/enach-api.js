const RepaymentInstallment = require("../models/repayment-installment-schema");
const LoanRequestSchema = require("../models/loan-request-schema");
const BorrowerinfoCommon = require("../models/borrowerinfo-common-schema.js");
const nachPresentmentSchema = require("../models/nach-presentment-schema");
const LoanStateSchema = require("../models/loan-state-schema");
const LoanTransactionsSchema = require("../models/loan-transaction-ledger-schema");
const moment = require("moment");
const jwt = require("../util/jwt");

module.exports = (app, connection) => {
  app.use(bodyParser.json());
  app.get(
    "/api/emi-data/:company_id/:product_id/:page/:limit/:status/:fromRange/:toRange/:searchBy",
    [jwt.verifyToken],
    async (req, res, next) => {
      try {
        const {
          company_id,
          product_id,
          page,
          limit,
          status,
          fromRange,
          toRange,
          searchBy
        } = req.params;
        const statusFilter = {
          All: ["cancelled", "rejected", "closed", "foreclosed", "settled"],
          Active: ["disbursed"],
          Inactive: [
            "disbursed",
            "cancelled",
            "rejected",
            "closed",
            "foreclosed",
            "settled"
          ]
        };
        const borrowerinfoRespByStatuses =
          await BorrowerinfoCommon.findKLIByStatuses(
            company_id,
            product_id,
            status === "Active" ? statusFilter[status] : [],
            status !== "Active" ? statusFilter[status] : []
          );

        let unique_loan_ids = borrowerinfoRespByStatuses.map((row) => {
          return row.loan_id;
        });
        unique_loan_ids = [...new Set(unique_loan_ids)];

        const { count, repaymentInstallments } =
          await RepaymentInstallment.getByCompanyIdAndProductId(
            req.params,
            unique_loan_ids
          );
        if (!repaymentInstallments.length)
          throw {
            success: false,
            message:
              "No records found in repayment installments for provided filter"
          };

        const leads = await LoanRequestSchema.findByLoanIds(unique_loan_ids);

        //nach presentation info
        const nachPresentMentData = await nachPresentmentSchema.findByLId(
          unique_loan_ids
        );
        //Fetch data from loan state schema against loan id
        const loanStateData = await LoanStateSchema.getByLoanIds(
          unique_loan_ids
        );
        //Fetch data from loan transaction ledger
        const loanTransactionLedgerResp =
          await LoanTransactionsSchema.findAllWithCondition({
            loan_id: { $in: unique_loan_ids },
            label: "repayment",
            is_received: "Y",
            processed: null
          });
        //Calculation for total txn_amount from loanTransaction ledger data.
        const txnAmountSumArray = [];
        loanTransactionLedgerResp.forEach((item) => {
          let flag = true;
          const tempObj = {};
          txnAmountSumArray.forEach((obj) => {
            if (obj.hasOwnProperty([item.loan_id])) {
              flag = false;
              obj[item.loan_id] = obj[item.loan_id] * 1 + item.txn_amount * 1;
            }
          });
          tempObj[item.loan_id] = item.txn_amount;
          if (flag) {
            txnAmountSumArray.push(tempObj);
          }
        });
        let repaymentInstallmentsObject = [];
        let idx = 1;
        const latestDueArray = [];
        repaymentInstallments.forEach((row) => {
          leads.forEach((lead) => {
            borrowerinfoRespByStatuses.forEach((record) => {
              if (lead.loan_id === row.loan_id) {
                if (record.loan_id === row.loan_id) {
                  let transactionAmtSum = 0;
                  let loanStateTxnSum = 0;
                  //Deduct excess repayment only for upcoming emi.
                  if (!latestDueArray.includes(row.loan_id)) {
                    txnAmountSumArray.forEach((obj) => {
                      if (obj.hasOwnProperty(row.loan_id)) {
                        transactionAmtSum = obj[row.loan_id];
                      }
                    });
                    loanStateData.forEach((loanState) => {
                      if (row.loan_id === loanState.loan_id) {
                        loanStateTxnSum = loanState?.excess_payment_ledger
                          ?.txn_amount
                          ? Number(loanState.excess_payment_ledger.txn_amount)
                          : 0;
                      }
                    });
                    latestDueArray.push(row.loan_id);
                  }
                  //check for nach status
                  const nach = nachPresentMentData.find((nach_presentment) => {
                    if (
                      nach_presentment.loan_id === row.loan_id &&
                      nach_presentment.emi_number === row.emi_no
                    )
                      return nach_presentment;
                  });
                  repaymentInstallmentsObject.push({
                    idx: idx++,
                    LOAN_NO: row.loan_id,
                    MANDATE_REF_NO: record.mandate_ref_no
                      ? record.mandate_ref_no
                      : "",
                    DUE_AMOUNT: Number(
                      Math.round(
                        (row.emi_amount -
                          transactionAmtSum -
                          loanStateTxnSum * 1 +
                          Number.EPSILON) *
                          100
                      ) / 100
                    ),
                    EMI_AMOUNT: Number(row.emi_amount),
                    DUE_DATE: moment(row.due_date).format("YYYY-MM-DD"),
                    CUST_NAME:
                      (lead?.first_name || "") + " " + (lead?.last_name || ""),
                    DUE_DAY:
                      Number(moment(row.due_date).diff(moment(), "d")) + 2,
                    EMI_NO: row.emi_no,
                    REPAY_SCHEDULE_ID: row.repay_schedule_id,
                    UMRN: record.umrn ? record.umrn : "",
                    checked: false,
                    nach_presentment_status: nach
                      ? nach.nach_status_description
                      : ""
                  });
                }
              }
            });
          });
        });

        res.send({
          count,
          length: repaymentInstallmentsObject.length,
          repaymentRecords: repaymentInstallmentsObject
        });
      } catch (error) {
        res.status(400).send(error);
      }
    }
  );
};
