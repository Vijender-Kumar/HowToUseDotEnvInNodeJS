const bodyParser = require("body-parser");
const { check, validationResult } = require("express-validator");
const jwt = require("../util/jwt");
const dradownReportHelper = require("../util/report");
const ReportStorageSchema = require("../models/report-storage-schema");
const ProductSchema = require("../models/product-schema");
const loan_transaction_ledgers = require("../models/loan-transaction-ledger-schema.js");
const moment = require("moment");
const fs = require("fs").promises;
const s3helper = require("../util/s3helper");
var XLSX = require("xlsx");
var json2xls = require("json2xls");
module.exports = (app, connection) => {
  app.use(bodyParser.json());

  //Api to fetch generated Loc drawdown report records
  app.get(
    "/api/loc-drawdown-reports/:page/:limit",
    [jwt.verifyToken],
    async (req, res) => {
      try {
        const company_id = req.authData.company_id;
        const drawdownLocReportResp =
          await ReportStorageSchema.getPaginatedData(
            req.params.page,
            req.params.limit,
            "loc_drawdown_report",
            company_id
          );
        if (!drawdownLocReportResp.rows.length)
          throw {
            success: false,
            message: " No records found for Loc Drawdown reports",
          };
        return res.status(200).send(drawdownLocReportResp);
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  //Api to download generated Loc drawdown report
  app.get(
    "/api/download-loc-drawdown-report/:id",
    [jwt.verifyToken],
    async (req, res) => {
      try {
        const drawdownLocReportResp = await ReportStorageSchema.findById(
          req.params.id
        );
        if (!drawdownLocReportResp)
          throw {
            success: false,
            message: "No record found for dpd report.",
          };
        const url = drawdownLocReportResp.s3_url.substring(
          drawdownLocReportResp.s3_url.indexOf("loc_drawdown_report")
        );
        const reportFromS3Resp = await s3helper.readFileFromS3(url);
        res.attachment(url);
        let filename = `loc_drawdown_report${Date.now()}.xlsx`;
        await fs.writeFile(filename, reportFromS3Resp);
        var workbook = XLSX.readFile(`./${filename}`, {
          dateNF: "yyyy-mm-dd",
        });
        var ws = workbook.Sheets["Sheet 1"];
        const data = XLSX.utils.sheet_to_json(ws, { raw: false });
        const UnlinkXls = await fs.unlink(
          path.join(__dirname, `../${filename}`)
        );
        return res.status(200).send(data);
      } catch (error) {
        console.log(error);
        return res.status(400).send(error);
      }
    }
  );

  // Api to generate drawdown report
  app.post(
    "/api/loc-drawdown-report",
    [
      check("company_id").notEmpty().withMessage("company_id is required"),
      check("product_id").notEmpty().withMessage("product_id is required"),
      check("from_date")
        .notEmpty()
        .withMessage("from_date is required")
        .matches(/^(\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$)/)
        .withMessage("Please enter valid from_date in YYYY-MM-DD format"),
      check("to_date")
        .notEmpty()
        .withMessage("to_date is required")
        .matches(/^(\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$)/)
        .withMessage("Please enter valid to_date in YYYY-MM-DD format"),
    ],
    [jwt.verifyToken, jwt.verifyUser, jwt.verifyCompany, jwt.verifyProduct],
    async (req, res) => {
      try {
        const data = req.body;
        let { company_id, product_id, from_date, to_date } = data;
        //Check for the Company ID

        if (company_id && company_id != req.company._id)
          throw { success: false, message: "company_id mismatch" };

        //validate the data in api payload

        const errors = validationResult(req);
        if (!errors.isEmpty())
          return res.status(422).json({
            success: false,
            message: errors.errors[0]["msg"],
          });
        if (from_date || to_date) {
          let fromDate = moment(from_date, "YYYY-MM-DD");
          let toDate = moment(to_date, "YYYY-MM-DD");
          if (from_date && to_date) {
            // Validate from date should not be greater than to date
            if (toDate.isBefore(fromDate))
              throw {
                success: false,
                message: "from_date should be less than to_date",
              };
            // Validate difference between from_date and to_date should be maximum one year
            let Days = toDate.diff(fromDate, "days");
            if (Days > process.env.MAXIMUM_DATE_RANGE_REPORT) {
              throw {
                success: false,
                message: `from_date and to_date should be within ${process.env.MAXIMUM_DATE_RANGE_REPORT} days`,
              };
            }
          }
        }
        let productResp = {};
        if (product_id) {
          // Fetch product details
          productResp = await ProductSchema.findById(product_id);
        }

        let { allow_loc } = productResp;
        if (!allow_loc) {
          throw {
            success: false,
            message:
              "Report cannot be generated because the product is not LOC",
          };
        }

        //Fetch Records From Transaction Ledger and Batch Collection
        let disbursmentDrawDownData = await loan_transaction_ledgers.aggregate([
          {
            $match: {
              product_id: parseInt(product_id),
              company_id: parseInt(company_id),
            },
          },
          {
            $lookup: {
              from: "loc_batch_drawdown",
              localField: "request_id",
              foreignField: "_id",
              as: "batch_request",
            },
          },
          {
            $lookup: {
              from: "borrowerinfo_commons",
              localField: "loan_id",
              foreignField: "loan_id",
              as: "borrower_info",
            },
          },
        ]);

        const reportPayload = [];
        if (disbursmentDrawDownData.length == 0) {
          throw {
            success: false,
            message: "Report cannot be generated as No Disbursment Data Found",
          };
        }

        if (disbursmentDrawDownData.length >= 5000) {
          throw {
            success: false,
            message: "Report cannot be generated as No Disbursment Data Found",
          };
        }
        Array.from(disbursmentDrawDownData).forEach((drawDownData) => {
          console.log(drawDownData);
          reportPayload.push({
            "Loan App Id": drawDownData.loan_app_id,
            "Loan Id": drawDownData.loan_id,
            "Borrower Id": drawDownData.borrower_id,
            "Partner Loan App Id":
              drawDownData.borrower_info.length > 0
                ? drawDownData.borrower_info[0].partner_loan_app_id
                : "",
            "Partner Loan Id":
              drawDownData.borrower_info.length > 0
                ? drawDownData.borrower_info[0].partner_loan_id
                : "",
            "Partner Borrower Id": drawDownData.partner_borrower_id,
            "Usage Id": drawDownData._id,
            Status: drawDownData.disbursement_status,
            "Drawdown Request Date":
              drawDownData.batch_request.length > 0
                ? drawDownData.batch_request[0].drawdown_request_creation_date
                : drawDownData.created_at,
            "Drawdown Amount": drawDownData.txn_amount,
            "Net Drawdown Amount": drawDownData.final_disburse_amt,
            "Usage Fees Including Gst": drawDownData.usage_fees_including_gst,
            "Usage Fees": drawDownData.upfront_usage_fee,
            "Gst Usage Fees": drawDownData.gst_on_usage_fee,
            "Cgst Usage Fees": drawDownData.cgst_on_usage_fee,
            "Sgst Usage Fees": drawDownData.sgst_on_usage_fee,
            "Igst Usage Fees": drawDownData.igst_on_usage_fee,
            "Upfront Int": drawDownData.upfront_interest,
            "Interest Rate":
              drawDownData.borrower_info.length > 0
                ? drawDownData.borrower_info[0].loan_int_rate
                : "",
            "Repayment Due Date": drawDownData.repayment_due_date,
            "Disbursement Date": drawDownData.utr_date_time_stamp,
            Remarks:
              drawDownData.batch_request.length > 0
                ? drawDownData.batch_request[0].remarks
                : "NA",
            "Disbursment Type":
              drawDownData.batch_request.length > 0 ? "Batch" : "RTD",
          });
        });
        const xls = json2xls(reportPayload, {
          fields: [
            "Loan App Id",
            "Loan Id",
            "Borrower Id",
            "Partner Loan App Id",
            "Partner Loan Id",
            "Partner Borrower Id",
            "Usage Id",
            "Status",
            "Drawdown Request Date",
            "Drawdown Amount",
            "Net Drawdown Amount",
            "Usage Fees Including Gst",
            "Usage Fees",
            "Gst Usage Fees",
            "Cgst Usage Fees",
            "Sgst Usage Fees",
            "Igst Usage Fees",
            "Upfront Int",
            "Interest Rate",
            "Repayment Due Date",
            "Disbursement Date",
            "Remarks",
            "Disbursment Type",
          ],
        });
        //Generate file name according to provided filter
        let fileName = `LOC_drawdown_${req.company.name}_${productResp.name}_${data.from_date}_${data.to_date}.xlsx`;

        // Convert json to xlsx format
        const localFilePath = await dradownReportHelper.convertJsonToExcel(
          fileName,
          xls
        );

        const uploadFileToS3 = await dradownReportHelper.uploadXlsxToS3(
          localFilePath,
          `loc_drawdown_report/${fileName}`
        );

        if (!uploadFileToS3)
          throw {
            success: false,
            message: "Error while uploading report to s3",
          };

        let reportData = {
          file_name: localFilePath,
          requested_by_name: req.user.username,
          requested_by_id: req.user._id,
          s3_url: uploadFileToS3.Location,
          company_name: req.company.name,
          company_code: req.company.code,
          product_name: data.product_id ? productResp.name : "",
          product_id: data.product_id ? data.product_id : "",
          company_id: data.company_id ? data.company_id : "",
          report_name: "loc_drawdown_report",
          from_date: data.from_date,
          to_date: data.to_date,
        };

        const recordGenereatedReport =
          await dradownReportHelper.recordGenereatedReport(reportData);
        if (!recordGenereatedReport)
          throw {
            success: false,
            message: "Error while recording generated report",
          };

        return res.status(200).send({
          message: "Loc Drawdown report generated successfully.",
          data: {},
        });
      } catch (error) {
        console.log(error);
        return res.status(400).send(error);
      }
    }
  );
};
