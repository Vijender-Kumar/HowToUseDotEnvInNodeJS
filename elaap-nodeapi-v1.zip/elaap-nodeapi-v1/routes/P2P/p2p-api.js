const { default: axios } = require("axios");
const bodyParser = require("body-parser");
const jwt = require("../../util/jwt");
const services = require("../../util/service");
const AccessLog = require("../../util/accessLog");
const disbursementHelper = require("../../utils/compositeDisbursementHelper.js");
const borrowerInfo = require("../../models/borrowerinfo-common-schema.js");
const moment = require("moment");

var {
    p2p_data_validator,
} = require("../../validator/P2P/p2p_utr_payload_validator");
/**
 * @author Tarun Kr Singh
 * @param {*} app
 * @param {*} connection
 * @return {*} 200, In case utr successfully updated
 * @throws {*} 400, with document code
 */
module.exports = (app) => {
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));
    app.post(
        "/api/co-lender-utr",
        [jwt.verifyToken,
        jwt.verifyCompany,
        services.isServiceEnabled(process.env.SERVICE_CO_LENDER_UTR_ID),
        AccessLog.maintainAccessLog
        ],
        async (req, res) => {
            try {
                let inputs = req.body;
                const errors = await p2p_data_validator(inputs);
                if (Object.keys(errors).length > 0 && errors.constructor === Object) {
                    throw {
                        statusCode: 400,
                        data: {
                            success : false,
                            message : "Invalid Payload",
                            errors: errors
                        }
                    };
                }
                const data = req.body;
                const requestBody = {
                    partner_utr: data.partner_utr,
                    loan_id: data.loan_id,
                    origin_utr: "",
                    loan_amount: data.loan_amount,
                    timestamp: data.timestamp
                }
                let response = {};
                await axios.request({
                    url: `${process.env.CO_LENDER_ORIGIN_P2P_ENDPOINT}`,
                    method: "PATCH",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': process.env.CO_LENDER_ORIGIN_BASIC_AUTH
                    },
                    data: requestBody
                }).then(async(res) => {
                    const loan_id = res.data.loan_id;
                    const webhookReq = {
                        payment_mode:"I"
                    }
                    const productResp = {
                        is_lender_selector_flag : "Y"
                    }
                    const borrowerInfoDetails = await borrowerInfo.findOneWithKLID(loan_id);
                    const txnData = {
                        company_id: borrowerInfoDetails?.company_id,
                        product_id: borrowerInfoDetails?.product_id,
                        company_name: borrowerInfoDetails?.company_name,
                        product_name: borrowerInfoDetails?.product_name,
                        loan_id: loan_id,
                        borrower_id: borrowerInfoDetails?.borrower_id,
                        partner_loan_id: borrowerInfoDetails?.partner_loan_id,
                        partner_borrower_id: borrowerInfoDetails?.partner_borrower_id,
                        disbursement_status: "COMPLETED",
                        utrn_number: data.partner_utr,
                        txn_date: moment(data.timestamp).format("YYYY-MM-DD"),
                        txn_amount: borrowerInfoDetails?.sanction_amount,
                        txn_id: loan_id,
                        txn_entry: "dr",
                        label: "disbursement",
                        record_method: "p2p",
                        webhook_status_code: "3",
                        txn_stage: "1",
                        bank_remark: "COMPLETED",
                        disbursement_date_time: data.timestamp,
                    }
                    await disbursementHelper.recordLoanTransaction(webhookReq, txnData, productResp);
                    await borrowerInfo.updateLoanStatus({stage:4,status:"disbursed"},loan_id);
                    response = {
                        statusCode: res.status,
                        data: {
                            success : res.data.success,
                            message : res.data.message
                        }
                    }
                }).catch(error => {
                    response = {
                        statusCode : error.response?.status,
                            data : {
                                success : error.response?.data.success,
                                message : error.response?.data.message
                            }
                    }
                });
                
                return res.status(response.statusCode).send(response)
            } catch (err) {
                console.log(err)
                return res.status(400).send(err)
            }
        })
};

