"use strict";
const AWS = require("aws-sdk");
const s3bucket = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  signatureVersion: 'v4',
  region: 'ap-south-1',
  Bucket: process.env.AWS_LOAN_TEMPLATE_BUCKET
});

const uploadPdfFileToS3 = (pdf, filename) => {
  // upload PDF file to S3 bucket
  const params = {
    Bucket: process.env.AWS_LOAN_TEMPLATE_BUCKET,
    Key: filename,
    Body: pdf
  }
  const promise = new Promise(function (resolve, reject) {
    try {
      s3bucket.upload(params, function (err, uploadedFile) {
        if (err) {
          reject(err);
        } else {
          resolve(uploadedFile.Location);
        }
      });
    } catch (error) {
      reject(error);
    }
  });
  return promise;
}


const getSignedUrl = async (filename) => {
  const params = {
    Bucket: process.env.AWS_LOAN_TEMPLATE_BUCKET,
    Key: filename,
    Expires: 60 * 5
  };
  try {
    const url = await new Promise((resolve, reject) => {
      s3bucket.getSignedUrl('getObject', params, (err, url) => {
        err ? reject(err) : resolve(url);
      });
    });
    return url;
  } catch (err) {
    if (err) {
      throw err;
    }
  }
}

const uploadLogsToS3 = (item, key) => {
  const obj = {
    ...item
  };
  obj.objRef = obj;
  
  const jsonString = JSON.stringify(obj, function(key, value) {
    if (typeof value === 'object' && value !== null) {
      if (key === 'objRef') {
        return '[Circular]';
      }
    }
    return value;
  });
  
  var params = {
    Bucket: process.env.AWS_LOAN_TEMPLATE_BUCKET,
    Key: key,
    Body: JSON.stringify(item)
  };
  const promise = new Promise(function(resolve, reject) {
    try {
      s3bucket.upload(params, function(err, uploadedFile) {
        if (err) {
          reject(err);
        } else {
          resolve(uploadedFile);
        }
      });
    } catch (error) {
      reject(error);
    }
  });
  return promise;
};

const uploadBase64ToS3 = (item, key) => {
  var params = {
    Bucket: process.env.AWS_LOAN_TEMPLATE_BUCKET,
    Key: key,
    Body: JSON.stringify(item)
  };
  const promise = new Promise(function(resolve, reject) {
    try {
      s3bucket.upload(params, function(err, uploadedFile) {
        if (err) {
          reject(err);
        } else {
          resolve(uploadedFile);
        }
      });
    } catch (error) {
      reject(error);
    }
  });
  return promise;
};

module.exports = {
  uploadPdfFileToS3,
  getSignedUrl,
  uploadBase64ToS3,
  uploadLogsToS3
}