const serviceReqResLog = require("../../../models/service-req-res-log-schema.js");
const { uploadLogsToS3 } = require("../utils/aws-s3-helper.js");
async function serviceLogging(s3Data, req, type) {
    const serviceDetails = {
        company_id: req.company._id,
        company_code: req.company.code,
        vendor_name: req.logData.vendor_name,
        request_id: req.logData.request_id,
        service_id: req.logData.service_id,
        api_name: req.logData.api_name,
        is_cached_response : req.logData.is_cached_response,
        loan_app_id: req.body.loan_app_id,
        timestamp: Date.now(),
        id_number: req.body.account_number || "",
        consent: req.body.consent,
        consent_timestamp: req.body.consent_timestamp,
    }
    if (type.toUpperCase() === "REQUEST") {
        const reqData = {
            ...serviceDetails,
            request_type: "request",
            response_type: "success",
        }
        const responseFromS3 = await s3Logging(s3Data, req, "request");
        const requestS3Url = responseFromS3.Location;
        reqData.raw_data = requestS3Url;
        const dbResp = await serviceReqResLog.addNew(reqData);
        if (!dbResp) throw {
            message: "Error while adding response data to database"
        };

    }
    if (type.toUpperCase() === "RESPONSE") {
        const reqData = {
            ...serviceDetails,
            request_type: "response",
            response_type: "success",
        }
        const responseFromS3 = await s3Logging(s3Data, req, "response");
        const respS3Url = responseFromS3.Location;
        reqData.raw_data = respS3Url;
        const dbResp = await serviceReqResLog.addNew(reqData);
        if (!dbResp) throw {
            message: "Error while adding response data to database"
        };

    }
    if (type.toUpperCase() === "ERROR") {
        const reqData = {
            ...serviceDetails,
            request_type: "response",
            response_type: "error",
        }
        const responseFromS3 = await s3Logging(s3Data, req, "error");
        const respS3Url = responseFromS3.Location;
        reqData.raw_data = respS3Url;
        const dbResp = await serviceReqResLog.addNew(reqData);
        if (!dbResp) throw {
            message: "Error while adding response data to database"
        };

    }
}

async function s3Logging(data, req, type) {
    if (type.toUpperCase() === "REQUEST") {
        let filename = Math.floor(10000 + Math.random() * 99999) + "_req";
        const reqKey = `${req.logData.api_name}/${req.logData.vendor_name}/${req.company._id}/${filename}/${Date.now()}.txt`;
        //upload request data on s3
        const uploadResponse = await uploadLogsToS3(data, reqKey);
        return uploadResponse;
    }
    if (type.toUpperCase() === "RESPONSE") {
        let filename = Math.floor(10000 + Math.random() * 99999) + "_res";
        const resKey = `${req.logData.api_name}/${req.logData.vendor_name}/${req.company._id}/${filename}/${Date.now()}.txt`;
        //upload request data on s3
        const uploadResponse = await uploadLogsToS3(data, resKey);
        return uploadResponse;
    }
    if (type.toUpperCase() === "ERROR") {
        let filename = Math.floor(10000 + Math.random() * 99999) + "_err";
        const errKey = `${req.logData.api_name}/${req.logData.vendor_name}/${req.company._id}/${filename}/${Date.now()}.txt`;
        //upload request data on s3
        const uploadResponse = await uploadLogsToS3(data, errKey);
        return uploadResponse;
    }
}

async function handleError(error,req,res){
    const msgString = error.message.validationmsg || error.errorType === 999 ? error.message : (error.errorType === 99 ? error.message : `Please contact the administrator`);
    const errorCode = error.message.validationmsg || error.errorType === 999 ? 400 : (error.errorType === 99 ? 404 : 500);
    if (errorCode == 400) {
            res.status(400).send({
            request_id: error.request_id,
            message: msgString,
            status: "fail"
        });
    } else {
        await serviceLogging(error, req, "error");
            res.status(errorCode).send({
            request_id: error.request_id,
            message: msgString,
            status: "fail"
        });
    }
}

module.exports = {
    serviceLogging,
    s3Logging,
    handleError
}