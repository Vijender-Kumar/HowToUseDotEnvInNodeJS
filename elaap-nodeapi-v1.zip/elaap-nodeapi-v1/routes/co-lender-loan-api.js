const bodyParser = require("body-parser");
const {check, validationResult} = require("express-validator");
const ColenderLoan = require("../models/co-lender-loan-schema.js");
const colenderProfileSchema = require("../models/co-lender-profile-schema.js");
const cbiProfileSchema = require("../models/cbi-loan-schema.js");
const selectorSchema = require("../models/selector-details-schema.js");
const axios = require("axios");
const jwt = require("../util/jwt");
const _borrowerInfoSchema = require("../models/borrowerinfo-common-schema.js");
const LoanRequestSchema = require("../models/loan-request-schema.js");
const ComplianceSchema = require("../models/compliance-schema.js");

module.exports = (app, connection) => {
  app.use(bodyParser.json());

  app.get(
    "/api/fetch-cbi-loan",
    async (req, res) => {
      try {
        const loan_id = req.query.loan_id;
        const colenderLoan = await cbiProfileSchema.getByLID(loan_id);
        return res.status(200).json(colenderLoan)
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get(
    "/api/fetch-loan-details",
    async (req, res) => {
      try {
        const loan_id = req.query.loan_id;
        const loanDetails = await _borrowerInfoSchema.findOneWithKLID(loan_id);
        return res.status(200).json(loanDetails)
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get(
    "/api/fetch-lead-details",
    async (req, res) => {
      try {
        const loan_app_id = req.query.loan_app_id;
        const loanDestails = await LoanRequestSchema.findByLId(loan_app_id);
        return res.status(200).json(loanDestails)
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get(
    "/api/fetch-ckyc-details",
    async (req, res) => {
      try {
        const loan_app_id = req.query.loan_app_id;
        const loanDestails = await ComplianceSchema.findByLoanAppId(loan_app_id);
        return res.status(200).json(loanDestails)
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get(
    "/api/co-lender-loans-report/:colenderId/:userId",
    async (req, res) => {
      try {
        const _colenderId = req.params.colenderId;
        const _colenderLoan = await _borrowerInfoSchema.findByCLI(_colenderId);
        return res.status(200).json(_colenderLoan)
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.post(
    "/api/selector-details",
    [
      check("loan_app_id").notEmpty().withMessage("Loan app id is required"),
    ],
    async (req, res) => {
      try {
        const error = validationResult(req)
        if(!error.isEmpty()){
            throw {
                success : false,
                message : error.errors[0]["msg"]
            }
        }
        const loan_app_id = req.body?.loan_app_id;
        const data ={
        enquiry_purpose : req.body?.enquiry_purpose,
        enquiry_stage: req.body?.enquiry_stage,
        bureau_type: req.body?.bureau_type,
        dscr : req.body?.dscr,
        consent:req.body?.consent,
        consent_timestamp: req.body?.consent_timestamp,
        product_type_code: req.body?.product_type_code,
        request_id_a_score: req.body?.request_id_a_score,
        request_id_b_score: req.body?.request_id_b_score,
        interest_rate: req.body?.interest_rate,
        ceplr_cust_id: req.body?.ceplr_cust_id,
        sanction_amount: req.body?.sanction_amount,
        tenure: req.body?.tenure,
        monthly_income: req.body?.monthly_income,
        }
        const _selectorData = await selectorSchema.findIfExistByLId(loan_app_id)
        if(!_selectorData){
          await selectorSchema.addNew(loan_app_id,data);
        }else{
          const _updatedSelectorData = await selectorSchema.updateByLID(loan_app_id,data);
        }
        return res.status(200).send({
          status: "SUCCESS",
          message: "Updated Successfully"
        })
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.post(
    "/api/selector-response",
    [
      check("loan_app_id").notEmpty().withMessage("loan_app_id is required"),
      check("enquiry_purpose").notEmpty().withMessage("enquiry_purpose is required"),
      check("bureau_type").notEmpty().withMessage("bureau_type is required"),
      check("dscr").notEmpty().withMessage("dscr is required"),
      check("consent").notEmpty().withMessage("consent is required"),
      check("consent_timestamp").notEmpty().withMessage("consent_timestamp is required"),
      check("sanction_amount").notEmpty().withMessage("sanction_amount is required"),
      check("tenure").notEmpty().withMessage("tenure is required"),
      check("last_name").notEmpty().withMessage("last_name is required"),
      check("appl_pan").notEmpty().withMessage("appl_pan is required"),
      check("gender").notEmpty().withMessage("gender is required"),
      check("appl_phone").notEmpty().withMessage("appl_phone is required"),
      check("resi_addr_ln1").notEmpty().withMessage("resi_addr_ln1 is required"),
      check("city").notEmpty().withMessage("city is required"),
      check("state").notEmpty().withMessage("state is required"),
      check("pincode").notEmpty().withMessage("pincode is required"),
      check("monthly_income").notEmpty().withMessage("monthly_income is required"),
      check("product_type_code").notEmpty().withMessage("product_type_code is required"),
    ],
    async (req, res) => {
      try {
        const error = validationResult(req)
        if(!error.isEmpty()){
            throw {
                success : false,
                message : error.errors[0]["msg"]
            }
        }
        const loan_app_id = req.body?.loan_app_id;
        const data = {
        enquiry_purpose : req.body?.enquiry_purpose,
        enquiry_stage: req.body?.enquiry_stage,
        bureau_type: req.body?.bureau_type,
        dscr : parseInt(req.body?.dscr),
        consent:req.body?.consent,
        consent_timestamp: req.body?.consent_timestamp,
        product_type_code: req.body?.product_type_code,
        request_id_a_score: req.body?.request_id_a_score,
        request_id_b_score: req.body?.request_id_b_score,
        interest_rate: parseFloat(req.body?.interest_rate),
        ceplr_cust_id: req.body?.ceplr_cust_id,
        sanction_amount: parseFloat(req.body?.sanction_amount),
        tenure: parseInt(req.body?.tenure),
        first_name:req.body?.first_name,
        middle_name:req.body?.middle_name ? req.body?.middle_name : " ",
        last_name:req.body?.last_name,
        dob:req.body?.dob,
        appl_pan:req.body?.appl_pan,
        gender:req.body?.gender,
        appl_phone:req.body?.appl_phone,
        address:req.body?.resi_addr_ln1,
        city:req.body?.city,
        loan_app_id:req.body?.loan_app_id,
        state: req.body?.state,
        pincode : req.body?.pincode.toString(),
        monthly_income : req.body?.monthly_income
        }

        const config = {
          method: "POST",
          url: process.env.SERVICE_MS_URL + "/api/co-lender-selector",
          headers: {
            "content-type": "application/json",
            "Authorization": process.env.SERVICE_MS_TOKEN
          },
          data: JSON.stringify(data),
        };
        const _selectorResponse = await axios(config);
        let is_submitted =false;
        if(_selectorResponse.data.status==="success"){
          is_submitted = true;
        }
      
        const _selectorResp = {
        is_submitted: is_submitted,
        co_lender_shortcode : _selectorResponse.data.co_lender_shortcode,
        co_lender_assignment_id : _selectorResponse.data.co_lender_assignment_id,
        co_lender_name : _selectorResponse.data.co_lender_full_name
        }
        const _selectorData = await selectorSchema.findIfExistByLId(loan_app_id);
        if(_selectorData){
          await selectorSchema.updateByLID(loan_app_id,_selectorResp);
        }
        return res.status(200).send({
          status: "SUCCESS",
          message: "Updated Successfully"
        })
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get(
    "/api/selector-basic-details/:loan_app_id",
    [
      check("loan_app_id").notEmpty().withMessage("Loan app id is required"),
    ],
    async (req, res) => {
      try {
        const error = validationResult(req)
            if(!error.isEmpty()){
                throw {
                    success : false,
                    message : error.errors[0]["msg"]
                }
            }
        const loan_app_id = req.params?.loan_app_id;
        const _selectorData = await selectorSchema.findIfExistByLId(loan_app_id)
        return res.status(200).json(_selectorData);
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.post(
    "/api/co-lender-loan",
    async (req, res) => {
      try {
        const colenderProfileData = req.body;
        const colenderProfileDataRes = await ColenderLoan.addOne(colenderProfileData);
        if (!colenderProfileDataRes)
          throw {
            message: "Error while adding co_lender loan detail to database"
          }
        return res.send({
          message: "Colender Loan Detail created successfully."
        });
      } catch (error) {
        return res.status(400).send(error);
      }
    }
  );

  app.get("/api/co-lender-loan-search", async (req, res) => {
    try {
      const co_lender_id = req.query.co_lender_id;
      const company_id = req.query.company_id;
      const product_id = req.query.product_id;
      const status = req.query.status;
      const min_co_lend_loan_amount = req.query.min_co_lend_loan_amount;
      const max_co_lend_loan_amount = req.query.max_co_lend_loan_amount;
      const from_created_at = req.query.from_created_at;
      const to_created_at = req.query.to_created_at;

      const data = {};
      co_lender_id && (data.co_lender_id = co_lender_id);
      company_id && (data.company_id = company_id);
      product_id && (data.product_id = product_id);
      status && (data.status = status);

      const co_lend_loan_amount = {};
      min_co_lend_loan_amount && (co_lend_loan_amount.$gte = min_co_lend_loan_amount);
      max_co_lend_loan_amount && (co_lend_loan_amount.$lte = max_co_lend_loan_amount);
      !(Object.keys(co_lend_loan_amount).length === 0) && (data.co_lend_loan_amount = co_lend_loan_amount);

      const created_at = {}
      from_created_at && (created_at.$gte = from_created_at);
      to_created_at && (created_at.$lte = to_created_at);
      !(Object.keys(created_at).length === 0) && (data.created_at = created_at);

      const page = Number(req.query.page_no);
      const limit = Number(req.query.size);

      const colenderProfileData = await colenderProfileSchema.findByColenderId(co_lender_id);
      var colenderLoanData = [];
      var count = 0;

      if (process.env.NON_COLENDER_NAMES.includes(colenderProfileData?.co_lender_shortcode) && product_id === "") {
        const nonColendersData = {};

        company_id && (nonColendersData.company_id = company_id);
        product_id && (nonColendersData.product_id = product_id);
        status && (nonColendersData.status = status);
        !(Object.keys(co_lend_loan_amount).length === 0) && (nonColendersData.co_lend_loan_amount = co_lend_loan_amount);
        !(Object.keys(created_at).length === 0) && (nonColendersData.created_at = created_at);

        var colenderLoanData1 = await ColenderLoan.findAll(nonColendersData);
        count = colenderLoanData1.length;
        colenderLoanData = await ColenderLoan.findAll(nonColendersData)
          .sort({ created_at: -1 })
          .limit(limit)
          .skip((page - 1) * limit)
          .exec();
      } else {
        if (process.env.NON_COLENDER_NAMES.includes(colenderProfileData?.co_lender_shortcode) && product_id) {
          const nonColendersData = {};
          company_id && (nonColendersData.company_id = company_id);
          product_id && (nonColendersData.product_id = product_id);
          status && (nonColendersData.status = status);
          !(Object.keys(co_lend_loan_amount).length === 0) && (nonColendersData.co_lend_loan_amount = co_lend_loan_amount);
          !(Object.keys(created_at).length === 0) && (nonColendersData.created_at = created_at);

          var colenderLoanData1 = await ColenderLoan.findAll(nonColendersData);
          count = colenderLoanData1.length;
          colenderLoanData = await ColenderLoan.findAll(nonColendersData)
            .sort({ created_at: -1 })
            .limit(limit)
            .skip((page - 1) * limit)
            .exec();
        } else {
          colenderLoanData = await ColenderLoan.findByColenderData(data)
            .sort({ created_at: -1 })
            .limit(limit)
            .skip((page - 1) * limit)
            .exec();
          count = await ColenderLoan.countDocuments(data);
        }
      }
      var colenderLoan = [];
      for await (let obj of colenderLoanData) {
        if (obj.co_lender_id) {
          const colenderData = await colenderProfileSchema.findByColenderId(obj.co_lender_id);
          colenderLoan.push({ ...obj._doc, co_lender_name: colenderData.co_lender_name });
        }
      }
      res.json({
        colenderLoan,
        count: count,
        totalPages: Math.ceil(count / limit),
        currentPage: page
      });
    }
    catch (error) {
      return res.status(400).send(error);
    }
  });

  app.get("/api/cbi-loan-search",
    [
      check("co_lender_id").notEmpty().withMessage("Colender name is required"),
    ],
    async (req, res) => {
      try {
        const error = validationResult(req)
            if(!error.isEmpty()){
                throw {
                    success : false,
                    message : error.errors[0]["msg"]
                }
            }
        const co_lender_id = req.query.co_lender_id;
        const company_id = req.query.company_id;
        const from_created_at = req.query.from_created_at;
        const to_created_at = req.query.to_created_at;
        const page = Number(req.query.page_no);
        const limit = Number(req.query.size);
        const status = req.query.status;

        const data = {};
        co_lender_id && (data.co_lender_id = co_lender_id);
        company_id && (data.company_id = company_id);
        status && (data.status = status);

        const created_at = {}
        from_created_at && (created_at.$gte = from_created_at);
        to_created_at && (created_at.$lte = to_created_at);
        !(Object.keys(created_at).length === 0) && (data.created_at = created_at);

        const colenderAllLoans= await cbiProfileSchema.findAll(data)
        const colenderLoans = await cbiProfileSchema.findByColenderData(data)
          .sort({ created_at: -1 })
          .limit(limit)
          .skip((page - 1) * limit)
          .exec();
        let colenderLoan = [];
          for await (let ele of colenderLoans) {
            colenderLoan.push(ele);
          }
        let count=0
        count = colenderAllLoans?.length
        res.json({
          colenderLoan,
          count: count,
          totalPages: Math.ceil(count / limit),
          currentPage: page
        });
      }
      catch (error) {
        return res.status(400).send(error);
      }
    });

  app.post("/api/co-lender-loan-decision",
    [
      check("loan_id").notEmpty().withMessage("Loan Id is required"),
      check("status").notEmpty().withMessage("Status is required"),
    ],
   async (req, res) => {
    try {
      const error = validationResult(req)
      if(!error.isEmpty()){
          throw {
              success : false,
              message : error.errors[0]["msg"]
          }
      }
      const loanId = req.body?.loan_id;
      const status = req.body?.status;
      const remarks = req.body?.remarks;
      const decision_date = req.body?.decision_date;
      const decision_change_date = req.body?.decision_change_date;
      const username = req.body?.username;
      const isApproved = (await cbiProfileSchema.findIfApproved(loanId))?.status?.toUpperCase()=== "HOLD"; 

      const colenderShortCode = (await cbiProfileSchema.findShortCode(loanId))?.co_lender_shortcode;
      const adapterTriggerData = {
        loan_id: loanId,
        co_lender_shortcode: colenderShortCode
      }
      const adapterUrl = process.env.CBI_LOAN_DECISION_URL;

      if(!isApproved){
        await cbiProfileSchema.updateColenderLoan(loanId, status, remarks, decision_date, username);
      }

      if(isApproved){
        const _prevStatus = (await cbiProfileSchema.findIfApproved(loanId))?.status;
        const _prevRemarks = (await cbiProfileSchema.findIfApproved(loanId))?.remarks;
        await cbiProfileSchema.modifyColenderLoan(loanId, _prevStatus, status, _prevRemarks, remarks, decision_change_date, username);
      }
      if (status.toUpperCase() === "APPROVED") {
        axios.post(
            adapterUrl,
            JSON.stringify(adapterTriggerData),
            {
              headers: {
                "Authorization":`Basic ${process.env.CBI_LOAN_DECISION_API_AUTHORIZATION}`,
                "Content-Type": "application/json",
              }
            })
      }
      return res.status(200).send({
        message: "success"
      });
    }
    catch (error) {
      return res.status(400).send(error);
    }
  });

  app.put(
    "/api/da-approval",
    [
      jwt.verifyToken,
      jwt.verifyUser,
      jwt.verifyCompany,
      jwt.verifyProduct,
    ],
    async (req, res, next) => {
      try {

        const _data = req.body;
        const _query = {
          loan_id : _data.loan_id
        }
        const _approvalDetails = {
          approve_for_da: _data.approve_for_da,
          approve_for_da_date: _data.approve_for_da_date,
          approved_by: _data.approved_by,
          approved_da: _data.approved_da
        }
        await _borrowerInfoSchema.findOneAndUpdate(_query,_approvalDetails)
        return res.status(200).send({
          message: "success"
        });
      }
      catch (error) {
        return res.status(400).send(error);
      }
    });
};