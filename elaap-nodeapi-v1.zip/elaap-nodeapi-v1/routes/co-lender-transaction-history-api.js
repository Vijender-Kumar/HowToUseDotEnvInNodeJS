const bodyParser = require("body-parser");
const ColendLoanTransactionLedger = require("../models/co-lend-loan-transaction-ledger-schema.js");

module.exports = (app, connection) => {
  app.use(bodyParser.json());

  app.get("/api/co-lender-transaction-history/:co_lend_loan_id/:co_lender_id", async (req, res) => {
    console.log(req.params);
    try {
      const profileRes =
        await ColendLoanTransactionLedger.getTransactionHistoryByLoanId(
          req.params.co_lend_loan_id,
          req.params.co_lender_id
        );
      console.log(profileRes);
      return res.send({
        success: true,
        message: "Success",
        data: profileRes,
      });
    } catch (error) {
      console.log(error);
      return res.status(400).send(error);
    }
  });
};
