var autoIncrement = require("mongoose-auto-increment");
var mongoose = require("mongoose");

const customerSchema = mongoose.Schema({
  id: {
    type: Number,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  cust_id: {
    type: String,
    allowNull: false
  },
  pan: {
    type: String,
    allowNull: false
  },
  first_name: {
    type: String,
    allowNull: false
  },
  middle_name: {
    type: String,
    allowNull: true
  },
  last_name: {
    type: String,
    allowNull: false
  },
  updatedon: {
    type: Date,
    default: Date.now
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  create_date: {
    type: Date,
    default: Date.now
  }
});

autoIncrement.initialize(mongoose.connection);
customerSchema.plugin(autoIncrement.plugin, "id");
var Customers = (module.exports = mongoose.model("customers", customerSchema));

module.exports.addNew = (customer) => {
  var insertdata = new Customers(customer);
  return insertdata.save();
};
module.exports.getAll = () => {
  return Customers.find({});
};

module.exports.findByPan = (pan) => {
  return Customers.find({ pan: pan });
};

module.exports.updateOne = (data, title) => {
  return Customers.findOneAndUpdate(
    {
      title
    },
    data,
    {}
  );
};

module.exports.getCount = () => {
  return Customers.find({}).count();
};

// for borrower-history-api
module.exports.findLoanHistoryByPan = (pan) => {
  return Customers.aggregate([
    {
      $match: {
        pan: pan
      }
    },
    {
      $lookup: {
        from: "loanrequests",
        localField: "cust_id",
        foreignField: "cust_id",
        as: "HISTORY"
      }
    },
    {
      $unwind: {
        path: "$HISTORY",
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $project: {
        _id: 0,
        company_id: "$HISTORY.company_id",
        product_id: "$HISTORY.product_id",
        loan_app_id: "$HISTORY.loan_app_id"
      }
    },
    {
      $lookup: {
        from: "borrowerinfo_commons",
        localField: "loan_app_id",
        foreignField: "loan_app_id",
        as: "LOAN"
      }
    },
    {
      $unwind: {
        path: "$LOAN",
        preserveNullAndEmptyArrays: false
      }
    },
    {
      $project: {
        company_id: 1,
        product_id: 1,
        co_lender_id: "$LOAN.co_lender_id",
        loan_id: {
          $ifNull: ["$LOAN.loan_id", ""]
        },
        disbursement_date: {
          $ifNull: ["$LOAN.disbursement_date_time", ""]
        },
        loan_status: {
          $ifNull: ["$LOAN.status", ""]
        },
        loan_amount: {
          $ifNull: ["$LOAN.sanction_amount", ""]
        }
      }
    },
    {
      $lookup: {
        from: "co_lender_profiles",
        localField: "co_lender_id",
        foreignField: "co_lender_id",
        as: "COLENDER"
      }
    },
    {
      $lookup: {
        from: "companies",
        localField: "company_id",
        foreignField: "_id",
        as: "COMPANY"
      }
    },
    {
      $lookup: {
        from: "products",
        localField: "product_id",
        foreignField: "_id",
        as: "PRODUCT"
      }
    },
    {
      $unwind: {
        path: "$COLENDER",
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $unwind: {
        path: "$COMPANY",
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $unwind: {
        path: "$PRODUCT",
        preserveNullAndEmptyArrays: true
      }
    },
    {
      $project: {
        _id: 0,
        loan_id: 1,
        disbursement_date: 1,
        loan_amount: 1,
        loan_status: 1,
        co_lender_id: "$COLENDER.co_lender_id",
        co_lender_shortcode: {
          $ifNull: ["$COLENDER.co_lender_shortcode", ""]
        },
        company_name: {
          $ifNull: ["$COMPANY.name", ""]
        },
        company_code: {
          $ifNull: ["$COMPANY.code", ""]
        },
        product_name: {
          $ifNull: ["$PRODUCT.name", ""]
        },
        product_code: {
          $ifNull: ["$PRODUCT.name", ""]
        }
      }
    }
  ]);
};
