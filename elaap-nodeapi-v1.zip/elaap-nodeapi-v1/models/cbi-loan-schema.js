var mongoose = require("mongoose");
const { Decimal128 } = require("mongodb");
var autoIncrement = require("mongoose-auto-increment");

var CbiLoanSchema = mongoose.Schema({
  id: {
    type: Number,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  co_lender_id: {
    type: Number,
    allowNull: true
  },
  co_lender_shortcode: {
    type: String,
    allowNull: true
  },
  product_id: {
    type: Number,
    allowNull: true
  },
  company_id: {
    type: Number,
    allowNull: true
  },
  loan_id: {
    type: String,
    allowNull: true
  },
  status: {
    type: String,
    allowNull: true
  },
  remarks: {
    type: String,
    allowNull: true
  },
  status_earlier: {
    type: String,
    allowNull: true
  },
  remarks_earlier: {
    type: String,
    allowNull: true
  },
  updated_by_username: {
    type: String,
    allowNull: true
  },
  username: {
    type: String,
    allowNull: true
  },
  co_lend_loan_amount: {
    type: Number,
    allowNull: true
  },
  created_at: {
    type: Date,
    allowNull: true,
    default: Date.now
  },
  decision_date: {
    type: Date,
    allowNull: true
  },
  decision_change_date: {
    type: Date,
    allowNull: true
  },
  updated_at: {
    type: Date,
    allowNull: true,
    default: Date.now
  }
});

var CBILoans = (module.exports = mongoose.model("cbi_loans", CbiLoanSchema));

module.exports.findByColenderData = (data) => {
  return CBILoans.find(data);
};

module.exports.findShortCode = (loan_id) => {
  return CBILoans.findOne({ loan_id: loan_id });
};

module.exports.getByLID = (loan_id) => {
  return CBILoans.findOne({ loan_id: loan_id });
};

module.exports.findByLoanID = (loan_id) => {
  return CBILoans.find({ loan_id: loan_id });
};

module.exports.findByProductID = (product_id) => {
  return CBILoans.find({ product_id: product_id });
};

module.exports.findAll = (data) => {
  return CBILoans.find(data).sort({ created_at: -1 });
};

module.exports.findNew = () => {
  return CBILoans.find({});
};
module.exports.findIfApproved = (loan_id) => {
  return CBILoans.findOne({
    loan_id: loan_id
  });
};
module.exports.updateColenderLoan = (
  loan_id,
  status,
  remarks,
  decision_date,
  username
) => {
  return CBILoans.findOneAndUpdate(
    {
      loan_id: loan_id
    },
    {
      status: status,
      remarks: remarks,
      decision_date: decision_date,
      username: username
    },
    {}
  );
};

module.exports.modifyColenderLoan = (
  loan_id,
  prev_status,
  status,
  prev_remarks,
  remarks,
  decision_change_date,
  username
) => {
  return CBILoans.findOneAndUpdate(
    {
      loan_id: loan_id
    },
    {
      status_earlier: prev_status,
      remarks_earlier: prev_remarks,
      status: status,
      remarks: remarks,
      decision_change_date: decision_change_date,
      updated_by_username: username
    },
    {}
  );
};

module.exports.addOne = async (colenderLoan) => {
  var newColenderLoan = new CBILoans(colenderLoan);
  try {
    return newColenderLoan.save();
  } catch (error) {
    return error;
  }
};
