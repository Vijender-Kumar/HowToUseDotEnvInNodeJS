var mongoose = require("mongoose");
mongoose.Promise = global.Promise;
var autoIncrement = require("mongoose-auto-increment");

const CamsDetailsSchema = mongoose.Schema({
  id: {
    type: Number,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  company_id: {
    type: Number,
    allowNull: false,
    required: true
  },
  product_id: {
    type: Number,
    allowNull: false
  },
  loan_app_id: {
    type: String,
    allowNull: false
  },
  gross_profit: {
    type: Number,
    allowNull: true
  },
  pbt: {
    type: Number,
    allowNull: true
  },
  total_revenue: {
    type: Number,
    allowNull: true
  },
  non_operating_income: {
    type: Number,
    allowNull: true
  },
  depreciation: {
    type: Number,
    allowNull: true
  },
  interest_expense: {
    type: Number,
    allowNull: true
  },
  pat: {
    type: Number,
    allowNull: true
  },
  equity: {
    type: Number,
    allowNull: true
  },
  reserve_and_surplus: {
    type: Number,
    allowNull: true
  },
  reserve_and_surplus: {
    type: Number,
    allowNull: true
  },
  secured_loans: {
    type: Number,
    allowNull: true
  },
  secured_loans: {
    type: Number,
    allowNull: true
  },
  unsecured_loans: {
    type: Number,
    allowNull: true
  },
  cc_od_limit: {
    type: Number,
    allowNull: true
  },
  short_term_liabilities: {
    type: Number,
    allowNull: true
  },
  long_term_liabilities: {
    type: Number,
    allowNull: true
  },
  intangible_assets: {
    type: Number,
    allowNull: true
  },
  debtors: {
    type: Number,
    allowNull: true
  },
  creditors: {
    type: Number,
    allowNull: true
  },
  stock: {
    type: Number,
    allowNull: true
  },
  current_assets: {
    type: Number,
    allowNull: true
  },
  inventory: {
    type: Number,
    allowNull: true
  },
  prepaid_expenses: {
    type: Number,
    allowNull: true
  },
  current_liabilities: {
    type: Number,
    allowNull: true
  },
  total_expenses: {
    type: Number,
    allowNull: true
  },
  opening_stock: {
    type: Number,
    allowNull: true
  },
  purchases: {
    type: Number,
    allowNull: true
  },
  working_capital: {
    type: Number,
    allowNull: true
  },
  total_assets: {
    type: Number,
    allowNull: true
  },
  retained_earnings: {
    type: Number,
    allowNull: true
  },
  total_liabilities: {
    type: Number,
    allowNull: true
  },
  total_debit_l6m: {
    type: Number,
    allowNull: true
  },
  total_debit_l3m: {
    type: Number,
    allowNull: true
  },
  total_credit_l6m: {
    type: Number,
    allowNull: true
  },
  total_credit_l3m: {
    type: Number,
    allowNull: true
  },
  mnthly_avg_bal_l6m: {
    type: Number,
    allowNull: true
  },
  mnthly_avg_bal_l3m: {
    type: Number,
    allowNull: true
  },
  latest_bal: {
    type: Number,
    allowNull: true
  },
  outward_chq_bounce_l6m: {
    type: Number,
    allowNull: true
  },
  outward_chq_bounce_l3m: {
    type: Number,
    allowNull: true
  },
  inward_chq_bounce_due_to_insuff_fnds_l6m: {
    type: Number,
    allowNull: true
  },
  inward_chq_bounce_due_to_insuff_fnds_l3m: {
    type: Number,
    allowNull: true
  },
  total_ecs_bounce_l6m: {
    type: Number,
    allowNull: true
  },
  total_ecs_bounce_l3m: {
    type: Number,
    allowNull: true
  },
  cnt_of_txn_decl_due_to_insuff_funds_l6m: {
    type: Number,
    allowNull: true
  },
  cnt_of_txn_decl_due_to_insuff_funds_l3m: {
    type: Number,
    allowNull: true
  },
  time_snce_lst_bounce: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_cash_withdrawls_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_atm_txn_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_cnt_of_atm_txn_l6m: {
    type: Number,
    allowNull: true
  },
  total_ecs_bounce_l3m: {
    type: Number,
    allowNull: true
  },
  cnt_of_txn_decl_due_to_insuff_funds_l6m: {
    type: Number,
    allowNull: true
  },
  time_snce_lst_bounce: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_cash_withdrawls_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_atm_txn_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_cnt_of_atm_txn_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_pos_txn_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_amt_of_cash_dep_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_annual_oblig: {
    type: Number,
    allowNull: true
  },
  thirty_dpd_l3m: {
    type: Number,
    allowNull: true
  },
  sixty_dpd_l6m: {
    type: Number,
    allowNull: true
  },
  ninety_dpd_l12m: {
    type: Number,
    allowNull: true
  },
  writeoff_settlement_l24m: {
    type: Number,
    allowNull: true
  },
  crrnt_cmr_score: {
    type: Number,
    allowNull: true
  },
  ttl_gst_turnover_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_gst_turnover_l3m: {
    type: Number,
    allowNull: true
  },
  lst_mnth_gst_turnover: {
    type: Number,
    allowNull: true
  },
  ttl_gst_paid_l6m: {
    type: Number,
    allowNull: true
  },
  ttl_gst_paid_l3m: {
    type: Number,
    allowNull: true
  },
  lst_mnth_gst_paid: {
    type: Number,
    allowNull: true
  },
  null_gst_filing_l6m: {
    type: Number,
    allowNull: true
  },
  one_shot_gst_filing_l6m: {
    type: Number,
    allowNull: true
  },
  cnt_of_gst_filing_missed_l6m: {
    type: Number,
    allowNull: true
  },
  cnt_of_gst_filing_missed_l3m: {
    type: Number,
    allowNull: true
  },
  ttl_itr_income_last_year: {
    type: Number,
    allowNull: true
  },
  ttl_itr_income_last_year_minus_one: {
    type: Number,
    allowNull: true
  },
  total_itr_tax_last_year: {
    type: Number,
    allowNull: true
  },
  total_itr_tax_last_year_minus_one: {
    type: Number,
    allowNull: true
  },
  itr_filing_missed_l2y: {
    type: Number,
    allowNull: true
  },
  advance_tax_paid_last_year: {
    type: Number,
    allowNull: true
  },
  ttl_itr_expense_last_year: {
    type: Number,
    allowNull: true
  },
  ttl_itr_expense_last_year_minus_one: {
    type: Number,
    allowNull: true
  },
  status: {
    type: String,
    allowNull: true,
    default: "open"
  },

  avg_banking_turnover_6_months: {
    type: Number,
    allowNull: true
  },
  number_of_deposit_txn: {
    type: Number,
    allowNull: true
  },
  number_of_withdrawal_txn: {
    type: Number,
    allowNull: true
  },
  abb: {
    type: Number,
    allowNull: true
  },
  abb_1: {
    type: Number,
    allowNull: true
  },
  abb_2: {
    type: Number,
    allowNull: true
  },
  business_type: {
    type: String,
    allowNull: true
  },
  business_vintage_overall: {
    type: Number,
    allowNull: true
  },
  no_of_customers: {
    type: Number,
    allowNull: true
  },
  program_type: {
    type: String,
    allowNull: true
  },
  applied_amount: {
    type: Number,
    allowNull: true
  },
  loan_int_rate: {
    type: Number,
    allowNull: true
  },
  vintage_months_partner_platform: {
    type: Number,
    allowNull: true
  },
  residence_vintage: {
    type: Number,
    allowNull: true
  },
  negative_area_check: {
    type: Number,
    allowNull: true
  },
  funding: {
    type: Number,
    allowNull: true
  },
  ltv: {
    type: Number,
    allowNull: true
  },
  bureau_type: {
    type: String,
    allowNull: true
  },
  bureau_score: {
    type: Number,
    allowNull: true
  },
  customer_type_ntc: {
    type: String,
    allowNull: true
  },
  bounces_in_three_month: {
    type: Number,
    allowNull: true
  },
  bounces_in_six_month: {
    type: Number,
    allowNull: true
  },
  max_dpd_last_6_months: {
    type: Number,
    allowNull: true
  },
  max_dpd_last_3_months: {
    type: Number,
    allowNull: true
  },
  max_dpd_last_12_months: {
    type: Number,
    allowNull: true
  },
  max_overdue_amount: {
    type: Number,
    allowNull: true
  },
  enquiries_bureau_30_days: {
    type: Number,
    allowNull: true
  },
  count_overdue_last_90_days: {
    type: Number,
    allowNull: true
  },
  count_emi_bounce_90_days: {
    type: Number,
    allowNull: true
  },
  foir: {
    type: Number,
    allowNull: true
  },
  emi_obligation: {
    type: Number,
    allowNull: true
  },
  business_expenses_6_months: {
    type: Number,
    allowNull: true
  },
  cash_runway: {
    type: Number,
    allowNull: true
  },
  annual_recurring_revenue: {
    type: Number,
    allowNull: true
  },
  recurring_revenue_growth: {
    type: Number,
    allowNull: true
  },
  avg_monthly_recurring_revenue: {
    type: Number,
    allowNull: true
  },
  annual_recurring_revenue_rate: {
    type: Number,
    allowNull: true
  },
  avg_monthly_revenue: {
    type: Number,
    allowNull: true
  },
  avg_monthly_gst_turnover: {
    type: Number,
    allowNull: true
  },
  avg_gst_turnover_l3m: {
    type: Number,
    allowNull: true
  },
  monthly_business_income: {
    type: Number,
    allowNull: true
  },
  current_od_cc_limit: {
    type: Number,
    allowNull: true
  },
  dbt_lss_sma_flag: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month_1: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month_2: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month_3: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month_4: {
    type: Number,
    allowNull: true
  },
  gtv_latest_month_5: {
    type: Number,
    allowNull: true
  },
  average_monthly_gtv: {
    type: Number,
    allowNull: true
  },
  dependency_on_anchor: {
    type: Number,
    allowNull: true
  },
  bill_type: {
    type: String,
    allowNull: true
  },
  no_of_months_gtv_data: {
    type: Number,
    allowNull: true
  },
  partner_score: {
    type: Number,
    allowNull: true
  },
  current_overdue_amount: {
    type: Number,
    allowNull: true
  },
  max_overdue_amount: {
    type: Number,
    allowNull: true
  },
  entity_name: {
    type: String,
    allowNull: true
  },
  loan_amount_requested: {
    type: Number,
    allowNull: true
  },
  creditor_days_cycle: {
    type: Number,
    allowNull: true
  }
});

autoIncrement.initialize(mongoose.connection);
CamsDetailsSchema.plugin(autoIncrement.plugin, "id");
var CamsDetails = (module.exports = mongoose.model(
  "cams_details",
  CamsDetailsSchema,
  "cams_details"
));

module.exports.addNew = (data) => {
  return CamsDetails.create(data);
};

module.exports.findByLAID = (loan_app_id) => {
  return CamsDetails.findOne({ loan_app_id });
};

module.exports.updateCamsDetails = (loan_app_id, data) => {
  return CamsDetails.findOneAndUpdate({ loan_app_id }, data, { new: true });
};
