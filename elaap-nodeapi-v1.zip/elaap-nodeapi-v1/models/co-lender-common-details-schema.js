var mongoose = require("mongoose");
const { Decimal128 } = require("mongodb");
const { ObjectId } = require("mongodb");

var ColenderCommonDetailsSchema = mongoose.Schema({
  id: {
    type: ObjectId,
    allowNull: true,
    autoIncrement: true,
    primaryKey: true
  },
  co_lender_utr_number: {
    type: String,
    allowNull: true
  },
  loan_id: {
    type: String,
    allowNull: true
  },
  created_at: {
    type: Date,
    allowNull: true,
    default: Date.now
  },
  updated_at: {
    type: Date,
    allowNull: true,
    default: Date.now
  }
});

var ColenderCommonDetails = (module.exports = mongoose.model(
  "co_lending_common_details",
  ColenderCommonDetailsSchema
));

module.exports.findByLoanID = (loan_id) => {
  return ColenderCommonDetails.findOne({ loan_id: loan_id });
};
