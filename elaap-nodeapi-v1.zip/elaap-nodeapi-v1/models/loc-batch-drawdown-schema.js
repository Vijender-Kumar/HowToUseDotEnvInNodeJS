const moment = require("moment");
var autoIncrement = require("mongoose-auto-increment");
var mongoose = require("mongoose");
mongoose.Promise = global.Promise;
const LocBatchDrawdownDataSchema = mongoose.Schema({
  id: {
    type: Number,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false
  },
  company_id: {
    type: Number,
    allowNull: false
  },
  product_id: {
    type: Number,
    allowNull: false
  },
  company_name: {
    type: String,
    allowNull: false
  },
  product_name: {
    type: String,
    allowNull: false
  },
  loan_app_id: {
    type: String,
    allowNull: false
  },
  loan_id: {
    type: String,
    allowNull: false
  },
  borrower_id: {
    type: String,
    allowNull: true
  },
  partner_loan_app_id: {
    type: String,
    allowNull: false
  },
  partner_loan_id: {
    type: String,
    allowNull: false
  },
  partner_borrower_id: {
    type: String,
    allowNull: false
  },
  first_name: {
    type: String,
    allowNull: false
  },
  last_name: {
    type: String,
    allowNull: false
  },
  borrower_mobile: {
    type: String,
    allowNull: false
  },
  usage_id: {
    type: Number,
    allowNull: false
  },
  no_of_emi: {
    type: Number,
    allowNull: false
  },
  status: {
    type: Number,
    allowNull: false
  },
  drawadown_request_date: {
    type: Date,
    allowNull: false
  },
  drawdown_amount: {
    type: Number,
    allowNull: false
  },
  net_drawdown_amount: {
    type: Number,
    allowNull: false
  },
  usage_fees_including_gst: {
    type: Number,
    allowNull: false
  },
  usage_fees: {
    type: Number,
    allowNull: false
  },
  gst_usage_fees: {
    type: Number,
    allowNull: false
  },
  cgst_usage_fees: {
    type: Number,
    allowNull: false
  },
  sgst_usage_fees: {
    type: Number,
    allowNull: false
  },
  igst_usage_fees: {
    type: Number,
    allowNull: false
  },
  upfront_int: {
    type: Number,
    allowNull: false
  },
  remarks: {
    type: String,
    allowNull: false
  },
  disbursement_date_time: {
    type: String,
    allowNull: false
  },
  disbursement_status_code: {
    type: Number,
    allowNull: false
  },
  utrn_number: {
    type: String,
    allowNull: false
  },
  txn_id: {
    type: String,
    allowNull: false
  },
  repayment_days: {
    type: Number,
    allowNull: true
  },
  drawdown_request_creation_date: {
    type: Date,
    allowNull: false,
    default: Date.now
  }
});
autoIncrement.initialize(mongoose.connection);
LocBatchDrawdownDataSchema.plugin(autoIncrement.plugin, "id");
var LocBatchDrawdownData = (module.exports = mongoose.model(
  " loc_batch_drawdown",
  LocBatchDrawdownDataSchema,
  "loc_batch_drawdown"
));

module.exports.addNew = async (data) => {
  const insertdata = new LocBatchDrawdownData(data);
  return insertdata.save();
};

module.exports.findByLoanId = (loan_id) => {
  return LocBatchDrawdownData.findOne({ loan_id });
};

module.exports.getFilteredNonProcessedRecords = async (filter) => {
  let query = {};
  const { company_id, product_id, page, limit, status } = filter;

  const count = await LocBatchDrawdownData.find({
    company_id,
    product_id,
    status
  }).count();
  const rows = await LocBatchDrawdownData.find({
    company_id,
    product_id,
    status
  })
    .sort({ _id: -1 })
    .skip(page * limit)
    .limit(limit);
  return {
    rows: rows,
    count: count
  };
};

module.exports.updateByLid = async (filter, data) => {
  return LocBatchDrawdownData.findOneAndUpdate(filter, data);
};

module.exports.getAllByLoanId = (loan_id) => {
  return LocBatchDrawdownData.aggregate([
    {
      $match: { loan_id : loan_id }
    },
    {
      $lookup: {
        from: "loan_transaction_ledgers",
        localField: "_id",
        foreignField: "request_id",
        as: "loan_transaction_ledger"
      }
    }
  ]);
}