var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const OfferDetailsSchema = mongoose.Schema({
  id: {
    type: Number,
    primaryKey: true,
    allowNull: false
  },

  offered_amount: {
    type: Number,
    allowNull: true
  },
  offered_int_rate: {
    type: Number,
    allowNull: true
  },
  monthly_average_balance: {
    type: Number,
    allowNull: true
  },
  monthly_imputed_income: {
    type: Number,
    allowNull: true
  },
  foir: {
    type: Number,
    allowNull: true
  },
  loan_app_id: {
    type: String,
    allowNull: false
  },
  created_at: {
    type: Date,
    allowNull: false,
    default: Date.now
  }
});

var OfferDetails = (module.exports = mongoose.model(
  "offer_details",
  OfferDetailsSchema,
  "offer_details"
));

module.exports.getAll = () => {
  return OfferDetails.find({});
};

module.exports.getByLoanAppId = (loanAppId) => {
  return OfferDetails.find({ loan_app_id: loan_app_id });
};

module.exports.findByReqId = (request_id) => {
  return OfferDetails.findOne({ request_id });
};
